function [searchp] = rand_assignment(zone_n_locs,...
    pointdata,...
    latdist,londist,h)

totalnum_allf_allSZ = sum(sum(h.f_array));

if isempty(h.constraints_array)
    
    searchp = zeros(1,totalnum_allf_allSZ);
    searchp_res1 = zeros(1,totalnum_allf_allSZ);
    while size(unique(searchp_res1),2) <  totalnum_allf_allSZ
        before = 0;
        for z_num = 1:size(h.f_array,1)
            for string_pos = before+1:before+sum(h.f_array(z_num,:))
                searchp(1,string_pos) = floor(rand*zone_n_locs(z_num)) +1;
                searchp_res1(1,string_pos) = pointdata{z_num,1}.pointslist(searchp(1,string_pos));
            end
            before = before + sum(h.f_array(z_num,:));
        end
    end
    
else
    
    max_tries = 10;
    
    try_again = 1;
    
    while try_again
        searchp = zeros(1,totalnum_allf_allSZ);
        searchp_res1 = zeros(1,totalnum_allf_allSZ);
        all_constraint_facs_array = sum(h.constraints_tzp1_array,3);
        all_constraint_facs_array2 = sum(h.constraints_tzp2_array,3);
        abort = 0;
        
        while size(unique(searchp_res1),2) <  totalnum_allf_allSZ && ~abort
            before = 0;
            
            for z_num = 1:size(h.f_array,1)
                
                for type_num = 1:size(h.f_array,2)
                    
                    if h.f_array(z_num,type_num) > 0
                        
                        string_pos = before + 1;
                        
                        while string_pos <= before+h.f_array(z_num,type_num) && ~abort
                            
                            done = 0;
                            tries = 1;
                            
                            while ~done && tries <= max_tries
                                searchp(1,string_pos) = floor(rand*zone_n_locs(z_num)) +1;
                                searchp_res1(1,string_pos) = pointdata{z_num,1}.pointslist(searchp(1,string_pos));
                                
%                                 searchp_res1
%                                 pause
                                
                                if size(unique(searchp_res1(1,1:string_pos)),2) == string_pos                                    
                                    
                                    if all_constraint_facs_array(z_num,type_num) > 0 || all_constraint_facs_array2(z_num,type_num) > 0 
                                            
                                        constraint_num = 1;
                                        crit_val_ok = 1;
                                        
                                        while constraint_num <= size(h.constraints_array,1)  && crit_val_ok                                            
                                            
                                            if h.constraints_tzp1_array(z_num,type_num,constraint_num) > 0  || ...
                                                    (h.constraints_array(constraint_num,2) == 1 && h.constraints_tzp2_array(z_num,type_num,constraint_num) > 0)
                                                
                                                if h.constraints_array(constraint_num,2) == 0
                                                    
                                                    %crit_value = h.zone_data{z_num,1}.criteria{h.constraints_array(constraint_num,3)}(searchp(1,string_pos));
                                                    crit_value = ...
                                                        h.zone_data{z_num,1}.criteria{h.constraints_array(constraint_num,3)}(pointdata{z_num,1}.localindex(searchp(1,string_pos)));
                                                    
                                                    %test = crit_value
                                                    
                                                    if h.constraints_array(constraint_num,1) == 1
                                                        
                                                        %test = h.constraints_array(constraint_num,8)
                                                        
                                                        if crit_value < h.constraints_array(constraint_num,8)
                                                            crit_val_ok = 0;
                                                        end
                                                    elseif h.constraints_array(constraint_num,1) == 2
                                                        if crit_value > h.constraints_array(constraint_num,8)
                                                            crit_val_ok = 0;
                                                        end
                                                    end
                                                    
                                                else
                                                    %%% NEED TO ADD INTER-FACILITY DISTANCE CONSTRAINTS
                                                    
                                                    
                                                    con_sites1_index = zeros(1,totalnum_allf_allSZ);
                                                    con_before = 0;
                                                    for z_con_num = 1:size(h.f_array,1)
                                                        for f_con_num = 1:size(h.f_array,2)
                                                            if h.constraints_tzp1_array(z_con_num,f_con_num,constraint_num) == 1
                                                                con_sites1_index(1,con_before+1:con_before+h.f_array(z_con_num,f_con_num)) = 1;
                                                            end
                                                            con_before = con_before+h.f_array(z_con_num,f_con_num);
                                                        end
                                                    end
                                                    con_sites1 = searchp_res1.*con_sites1_index;
                                                    con_sites1 = con_sites1(find(con_sites1 > 0));
                                                    
                                                    con_sites2_index = zeros(1,totalnum_allf_allSZ);
                                                    con_before = 0;
                                                    for z_con_num = 1:size(h.f_array,1)
                                                        for f_con_num = 1:size(h.f_array,2)
                                                            if h.constraints_tzp2_array(z_con_num,f_con_num,constraint_num) == 1
                                                                con_sites2_index(1,con_before+1:con_before+h.f_array(z_con_num,f_con_num)) = 1;
                                                            end
                                                            con_before = con_before+h.f_array(z_con_num,f_con_num);
                                                        end
                                                    end
                                                    con_sites2 = searchp_res1.*con_sites2_index;
                                                    con_sites2 = con_sites2(find(con_sites2 > 0));                                                    
                                                   
                                                    if size(con_sites1,2) >= 1&& size(con_sites2,2) >= 1
                                                        
                                                        [crit_val_ok] = check_dist_groups(con_sites1,...
                                                            con_sites2,latdist,londist,...
                                                            h.sizeTerrain1,h.constraints_array(constraint_num,:));

%                                                         pause
                                                    end                                                    
                                                   
                                                    %%% CHECKS HERE
                                                end
                                                
                                                if crit_val_ok
                                                    constraint_num = constraint_num + 1;
                                                end
                                                
                                            else
                                                constraint_num = constraint_num + 1;
                                            end
                                            
                                        end
                                        
                                        if crit_val_ok
                                            done = 1;
                                        end
                                        
                                    else
                                        done = 1;
                                    end
                                    
                                end
                                
                                if ~done
                                    tries = tries + 1;
                                end
                            end
                            
                            %pause
                            
                            if ~done
                                abort = 1;
                            else
                                string_pos = string_pos +1;
                            end
                        end
                        before = before + h.f_array(z_num,type_num);
                    end
                end
            end
        end
        
        if ~abort
            try_again = 0;
        end
        
    end
    
end

searchp = searchp';

before = 0;
for z_num = 1:size(h.f_array,1)
    for f_num = 1:size(h.f_array,2)
        if h.f_array(z_num,f_num) ~= 0 && h.f_array(z_num,f_num) >= 2
            searchp(before+1:before+h.f_array(z_num,f_num)) = sort(searchp(before+1:before+h.f_array(z_num,f_num)));
            before = before + h.f_array(z_num,f_num);
        end
    end
end

if size(unique(searchp_res1(1,1:totalnum_allf_allSZ)),2) <  totalnum_allf_allSZ ...
        
searchp_res1
unique(searchp_res1(1,1:totalnum_allf_allSZ))
size(unique(searchp_res1(1,1:totalnum_allf_allSZ)),2)
pause

end

% searchp_res1
% plot([1 1 385 385],[1 325 1 325],'.')
% axis square
% hold

%         [rows,cols] = ind2sub(h.sizeTerrain1,searchp_res1);
%         plot(cols(1:6),rows(1:6),'*g')
%         plot(cols(7:12),rows(7:12),'*y')




end

