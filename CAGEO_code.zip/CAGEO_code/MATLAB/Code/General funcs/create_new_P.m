function [ newP, newobjP, Pareto_obj, new_pop_size, newprank] = create_new_P( P,objP, n_obj, new_population_size )

newP = P;
newobjP = objP;
Pareto_obj = zeros(n_obj,1);
new_pop_size = new_population_size;
newprank = zeros(1,new_population_size);

[F, front_size, newprank, n_frnts] = partition_n_obj(objP,n_obj);


if size(P,2) > new_population_size
    newprank = zeros(1,new_population_size);
    
    Pareto_obj = objP(1:n_obj,F(1,1:front_size(1)));
    
    newP = [];
    newobjP = zeros(n_obj+1,new_population_size);
    newprank = zeros(1,new_population_size);
    startsize = 0;
    i = 1;
    while (size(newP,2)<new_population_size)
        
        current_front_size = front_size(i);
        span = startsize+[1:current_front_size];
        
        if (current_front_size+size(newP,2)<=new_population_size)
            newP=cat(2,newP,P(:,F(i,1:current_front_size)));
            newobjP(1:n_obj,span)=objP(1:n_obj,F(i,1:current_front_size));
            newobjP(n_obj+1,span)=span;
            startsize = size(newP,2);
            newprank(1,span) = i;
        else
            % if a certain front Fi does not fit in P, put solutions of Fi in Rc to calculate crowding distance
            objRc=zeros(n_obj+1,current_front_size);
            Rc=P(:,F(i,1:current_front_size));
            objRc(1:n_obj,1:current_front_size)=objP(1:n_obj,F(i,1:current_front_size));
            objRc(n_obj+1,1:current_front_size)=1:current_front_size;
            
            cd = crowding_distance_n_obj(size(Rc,2),n_obj,objRc);
            cd=get_order(cd);
            sizediff = new_population_size - size(newP,2);
            newP=cat(2,newP,Rc(:,cd(1:sizediff)));
            newobjP(1:n_obj,startsize+[1:sizediff])=objRc(1:n_obj,cd(1:sizediff));
            newobjP(n_obj+1,startsize+[1:sizediff])=startsize+[1:sizediff];
            newprank(1,startsize+[1:sizediff]) = i;
            startsize = size(newP,2);
            
        end
        i = i + 1;
    end
end
new_pop_size = size(newP,2);
%end

end

