sites = [];

load('run_1.mat','numruns','Pareto_solutions');
num_towers_per_solution = size(Pareto_solutions(:,1),1);

for run_count = 1:numruns
    
    load(strcat('run_',num2str(run_count),'.mat'),'Pareto_solutions');
    
    for row = 1:num_towers_per_solution
        sites = unique(cat(2,sites,Pareto_solutions(row,:)));
    end

end