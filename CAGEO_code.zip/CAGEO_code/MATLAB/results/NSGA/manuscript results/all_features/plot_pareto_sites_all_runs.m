get_pareto_sites_all_runs

hold;

PZ_num = 1; % feasible_roads and slope
%PZ_num = 2; % feasible_roads and slope and limited to peaks and ridges

load('C:\Users\rangerandries\Desktop\CAGEO_code\MATLAB\cwds_landforms_data.mat','Terrain1','zone_data')

terrainsize = size(Terrain1);

PZ = zeros(size(Terrain1));
PZ(zone_data{PZ_num,1}.feasible1) = 1;
mesh(PZ)

[rows,cols] = ind2sub(terrainsize,sites');
plot3(cols,rows,zeros(1,size(sites,2))+11,'o','MarkerFaceColor','r','MarkerEdgeColor','k','MarkerSize',10,'LineWidth',1)

h = gcf;
set(h,'units','normalized','outerposition',[0 0 1 1])
set(h,'Color','w')
grid off
axis off
axis([1 terrainsize(2) 1 terrainsize(1)])
set(gca, 'Color', 'none');
view(2)

