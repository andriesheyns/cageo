function [P, objP, time,interrupt,lostime] = ...
    NSGAII(n_obj,...
    pointdata,...
    parameters,startP,startobj,h,timevec,current_res)

% axes(h.candidate_locations);
% plotcolour = '.g';
% [rows,cols] = ind2sub(h.sizeTerrain1,h.SZ1_feasible1(SZ1_local_index));
% if h.doplots
%     plot(cols,rows,plotcolour,'MarkerSize',5);
% end
%
% plotcolour = '.b';
% [rows,cols] = ind2sub(h.sizeTerrain1,h.SZ2_feasible1(SZ2_local_index));
% if h.doplots
%     plot(cols,rows,plotcolour,'MarkerSize',5);
% end

% pause
% updateplots('.g',n_obj,startobj,h);
% pause


% if current_res == 1
% cover_array1 = load_cover_arrays(15,1,h,...
%     pointdata{9,1}.pointslist,h.iz_data{6,1}.interest1);
% cover_array2 = load_cover_arrays(30,1,h,...
%     pointdata{9,1}.pointslist,h.iz_data{2,1}.interest1);
% save('testing.mat','cover_array1','cover_array2','pointdata')
% else
%     cover_array1 = [];
%     cover_array2 = [];
% end

rng('shuffle');

format long;

lostime = [0 0];

starttic = tic;
totaltime = timevec(1);
runtime = timevec(2);
interrupt = 0;
set(h.current_tcount_display,'String','0');
set(h.current_gen_display,'String','1');

population_size=parameters(1);
tour_size=parameters(2);
pool_size=parameters(3);
crossover_p = parameters(4);
mutation_p=parameters(5);
threshold =parameters(6);
threshold_count_limit=parameters(7);
time = [];

f = 1/298.257223563;
a = 6378137;
latdist = vdist(h.lat,0,h.lat + 1/3600,0,a,f);
londist = vdist(h.lat,0,h.lat,1/3600,a,f);

halved_cnt = 0;

%all_points = [];
for i = 1:size(h.zone_data,1)
    zone_n_locs(i) = size(pointdata{i,1}.pointslist,2);
    %     if sum(h.f_array(i,:)) > 0
    %         all_points = cat(2,all_points,pointdata{i,1}.pointslist);
    %     end
end
% all_points = unique(all_points);

totalnum_allf_allSZ = sum(sum(h.f_array));
P=zeros(totalnum_allf_allSZ,population_size);
objP=zeros(n_obj+1,population_size);
prev_pop_obj = [];%zeros(totalnum_allf_allSZ+n_obj,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%
visresults_mem = [];
%%%%%%%%%%%%%%%%%%%%%%%%%%%

P=zeros(totalnum_allf_allSZ,population_size);
objP=zeros(n_obj+1,population_size);
%%%%%%INITIAL POPULATION
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%%%%%%%%%%%%%%%%%%CARRIED OVER
if ~isempty(startP)
    
else
    %%%%%%%%%%%%%%%%%%GENERATE NEW
    for i=1:population_size
        i
        [P(1:totalnum_allf_allSZ,i)] =...
            rand_assignment(zone_n_locs,...
            pointdata,...
            latdist,londist,h);
        
        updatetime(starttic,totaltime,runtime,h);
%         if strcmp(get(h.STOP,'String'),'STOPPED')
%             interrupt = 1;
%             return
%         end
    end
       
    
    [objP, lostime] =evaluate_chromosome_population...
        (P,n_obj,pointdata,...
        lostime,h,prev_pop_obj,current_res,visresults_mem);
    
    objP(n_obj+1,:)=1:size(objP,2);
    updatetime(starttic,totaltime,runtime,h);
    
    [P,objP] = filter_front(P,objP);
    population_size = size(objP,2);
    if mod(population_size,2) ~= 0
        pool_size = (population_size+1)/2;
    end
    population_size_i = population_size;
    objP(n_obj+1,:) = 1:size(objP,2);
    set(h.current_psize_display,'String',num2str(population_size));
    drawnow;
    
    [F, front_size, prank, ~] = partition_n_obj(objP,n_obj);
    prev_Pareto = P(:,F(1,1:front_size(1)));
    prev_Pareto = unique(prev_Pareto','rows')';
    
    prev_P = P;
    prev_P = unique(prev_P','rows')';
    
    generation = 1;
    time(generation,1) = toc(starttic);
    %%%%%%START ITERATIONS
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    generation=2;
    thresholdcount = 0;
    halfcount = 0;
    half_pop_done = false;
    half_pop = false;
    
    prev_pop_obj = [];%cat(1,P,objP);
    

    convg_load = 0;
    while thresholdcount < threshold_count_limit 
               
        updatetime(starttic,totaltime,runtime,h);
        
        set(h.current_gen_display,'String',num2str(generation));
        drawnow
        
%         if strcmp(get(h.STOP,'String'),'STOPPED')
%             interrupt = 1;
%             return
%         end
        
        generationtic = tic;
        
        cd = crowding_distance_n_obj(size(P,2),n_obj,objP);
        
        [Q]  = generate_children(P,zone_n_locs,...
            pointdata,...
            prank,cd,tour_size,pool_size,population_size,...
            crossover_p,mutation_p,latdist,londist,...
            h.NSGA_CRP,h,current_res);
        
        dummy = zeros(1,size(Q,2));
        [Q,~] = filter_front(Q,dummy);
        
        objQ = zeros(n_obj,size(Q,2));
        
        [objQ,lostime]=evaluate_chromosome_population...
            (Q,n_obj,pointdata,...
            lostime,h,prev_pop_obj,current_res,visresults_mem);
        
        updatetime(starttic,totaltime,runtime,h);
        
%         if strcmp(get(h.STOP,'String'),'STOPPED')
%             interrupt = 1;
%             return
%         end
        
        drawnow
        
        R=cat(2,P,Q);
        objR=cat(2,objP(1:n_obj,:),objQ);
        [R,objR] = filter_front(R,objR);
        objR(n_obj+1,:) = 1:size(objR,2);
        
        %[F, front_size, prank, n_frnts] = partition_n_obj(objR,n_obj);
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        if h.half_NSGA_pop
            if ~half_pop_done
                if half_pop
                    halved_cnt = halved_cnt+1;
                    population_size = round(population_size_i/2);
                    population_size_i = population_size;
                    if mod(population_size,2) ~= 0
                        population_size = population_size + 1;
                    end
                    pool_size = population_size/2;
                    if halved_cnt == 2;
                        half_pop_done = true;
                    end
                    half_pop = false;
                    halfcount = 0;
                end
            end
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        set(h.current_psize_display,'String',num2str(population_size));
        drawnow;
        
        [ P, objP,~,~, prank] = create_new_P( R,objR, n_obj, population_size );
        
        [P,objP,prank] = filter_front_prank(P,objP,prank,h.f_array);
        population_size = size(objP,2);
        if mod(population_size,2) ~= 0
            pool_size = (population_size+1)/2;
        end
        %population_size_i = population_size;
        objP(n_obj+1,:) = 1:size(objP,2);
        set(h.current_psize_display,'String',num2str(population_size));
        drawnow;
        
        prev_pop_obj = [];%cat(1,P,objP);
        
        
        %%%%%%THRESHOLD CHECK
        %%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%
        %current_Pareto = P(:,F(1,1:front_size(1)));
        current_Pareto = P(:,find(prank == 1));
        current_Pareto = unique(current_Pareto','rows')';
        
        combined_Pareto = cat(2,current_Pareto,prev_Pareto);
        
        combined_count = size(combined_Pareto,2);
        combined_Pareto = unique(combined_Pareto','rows')';
        
        same_count = combined_count - size(combined_Pareto,2);
        
        clear combined_Pareto
        
        same_perc = same_count/size(current_Pareto,2);
        
        if same_perc < threshold
            thresholdcount = 0;
            set(h.current_tcount_display,'String',num2str(0));
            drawnow
        else
            thresholdcount = thresholdcount + 1;
            set(h.current_tcount_display,'String',num2str(thresholdcount));
            drawnow
        end
        
        prev_Pareto = current_Pareto;
        
        %%%%%%%%%%%%%%%%%%%half population size
        if h.half_NSGA_pop
            if ~half_pop_done
                combined_P = cat(2,P,prev_P);
                
                combined_count = size(combined_P,2);
                combined_P = unique(combined_P','rows')';
                
                same_count = combined_count - size(combined_P,2);
                
                clear combined_P
                
                same_perc = same_count/size(P,2);
                
                if ~half_pop
                    if same_perc > h.threshold_half/100
                        halfcount = halfcount + 1
                        if halfcount == h.threshold_count_half
                            half_pop = true;
                        end
                    else
                        halfcount = 0;
                    end
                end
                
                prev_P = P;
            end
        end
        %%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%
        
        time(generation,1) = toc(generationtic);
        generation=generation+1;
        
        
        
    end
    
    objP(n_obj+1,:)=[];
    disp('remember cat front instead of pre-declaring n_P by n_P to save memory');
    
end
