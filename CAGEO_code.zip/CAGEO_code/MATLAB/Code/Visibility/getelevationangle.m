function [ angle_rad ] = getelevationangle( pointheight,pointeast,pointnorth,beginheight,beginoffset,begineast,beginnorth )

 angle_rad = atan((pointheight -beginheight - beginoffset)/sqrt((pointeast - begineast)^2+(pointnorth - beginnorth)^2));

end

