function updatetime(starttic,totaltime,runtime,gui_handles)

currenttime = toc(starttic);
        hours = floor(currenttime/3600);
        minutes = floor((currenttime - (hours*3600))/60);
        tdisplay = strcat(num2str(hours),'h',num2str(minutes),'m');
        set(gui_handles.current_restime_display,'String',tdisplay);
        
        ttime = toc(totaltime);
        hours = floor(ttime/3600);
        minutes = floor((ttime - (hours*3600))/60);
        tdisplay = strcat(num2str(hours),'h',num2str(minutes),'m');
        set(gui_handles.total_runtime_display,'String',tdisplay);
        
        rtime = toc(runtime);
        hours = floor(rtime/3600);
        minutes = floor((rtime - (hours*3600))/60);
        tdisplay = strcat(num2str(hours),'h',num2str(minutes),'m');
        set(gui_handles.current_runtime_display,'String',tdisplay);
        drawnow

end

