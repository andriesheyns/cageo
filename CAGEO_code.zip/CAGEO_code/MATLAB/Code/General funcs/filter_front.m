function [ resultP, resultObj ] = filter_front( P,Obj)

resultP = unique(P','rows')';
resultObj = zeros(size(Obj,1),size(resultP,2));

for solution = 1:size(resultP,2)
    found = 0;
    compare = 1;
    while ~found
        if resultP(:,solution) == P(:,compare)
            resultObj(:,solution) = Obj(:,compare);
            found = 1;
        end
        compare = compare + 1;
    end
    if any(0 == resultP(:,solution))
        remove = cat(2,remove,solution);
    end
end

end

