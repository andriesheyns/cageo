function [distokay] = check_dist_groups(...
    group1_res1_points_grid,group2_res1_points_grid,...
    latdist,londist,max_matrix_size,constraint)

if (size(group1_res1_points_grid,2) == size(group2_res1_points_grid,2) && ...
        ~any(0 == (group1_res1_points_grid == group2_res1_points_grid))) && ...
        (size(group1_res1_points_grid,2) == 1)
    distokay = true;
else
    
    checkmin = constraint(1) == 1;
    checkmax = constraint(1) == 2;
    
    forcelinked = constraint(9);
    distconstraint = constraint(8);
    
    if forcelinked
        group2_res1_points_grid = group1_res1_points_grid;
    end
    
    [candidaterows_group1,candidatecols_group1] = ind2sub(max_matrix_size,group1_res1_points_grid);
    %%%%%group 1 same as group 2
    if size(group1_res1_points_grid,2) == size(group2_res1_points_grid,2) && ...
            ~any(0 == (group1_res1_points_grid == group2_res1_points_grid))
        
        n_f_tocheck = size(group1_res1_points_grid,2);
        
        if checkmax
            maxdistmatrix = zeros(n_f_tocheck);
        end
        
        distokay = true;
        alldone = false;
        first = 1;
        second = first + 1;
        
        while distokay && ~alldone
            
            latdiff = candidaterows_group1(first) - candidaterows_group1(second);
            londiff = candidatecols_group1(first) - candidatecols_group1(second);
            dist = sqrt((latdist*latdiff)^2 + (londist*londiff)^2);
            
            if checkmin
                if (dist <= distconstraint)
                    distokay = false;
                end
            end
            if checkmax
                if (dist <= distconstraint)
                    maxdistmatrix(first,second) = 1;
                    maxdistmatrix(second,first) = 1;
                end
            end
            if distokay
                
                if second < n_f_tocheck
                    second = second + 1;
                else
                    if first < n_f_tocheck - 1
                        first = first + 1;
                        second = first + 1;
                    else
                        alldone = true;
                    end
                end
            end
            
        end
        
        if distokay
            if checkmax
                if forcelinked
                    distokay = checkmaxdist(maxdistmatrix);
                else
                    distokay = checkmaxdist_notlinked(maxdistmatrix);
                end
            end
        end
        
    else
        
        [candidaterows_group2,candidatecols_group2] = ind2sub(max_matrix_size,group2_res1_points_grid);
        n_f_tocheck_group1 = size(group1_res1_points_grid,2);
        n_f_tocheck_group2 = size(group2_res1_points_grid,2);
        
        distokay = true;
        alldone = false;
        g1 = 1;
        g2 = 1;
        
        if checkmax
            maxdistmatrix = zeros(n_f_tocheck_group1,n_f_tocheck_group2);
        end
        
        while distokay && ~alldone
            
            latdiff = candidaterows_group1(g1) - candidaterows_group2(g2);
            londiff = candidatecols_group1(g1) - candidatecols_group2(g2);
            dist = sqrt((latdist*latdiff)^2 + (londist*londiff)^2);
            
            if checkmin
                if (dist <= distconstraint) && (group1_res1_points_grid(g1) ~= group2_res1_points_grid(g2))
                    distokay = false;
                end
            end
            if checkmax
                if (dist <= distconstraint) && (group1_res1_points_grid(g1) ~= group2_res1_points_grid(g2))
                    maxdistmatrix(g1,g2) = 1;
                end
            end
            if distokay
                
                if g2 == n_f_tocheck_group2
                    if g1 < n_f_tocheck_group1
                        g1 = g1 + 1;
                        g2 = 1;
                    else
                        alldone = true;
                    end
                else
                    g2 = g2 + 1;
                end
            end
            
        end
        if distokay && checkmax
            distokay = checkmaxdist_notlinked_groups(maxdistmatrix);
        end
    end
end
end

