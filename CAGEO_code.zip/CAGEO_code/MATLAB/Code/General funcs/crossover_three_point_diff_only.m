function [Q, constraints_ok] = crossover_three_point_diff_only...
    (P1,P2,...
    zone_n_locs,pointdata,...
    latdist,londist,...
    h)

totalnum_allf_allSZ = sum(sum(h.f_array));

Q=zeros(totalnum_allf_allSZ,2);

constraints_ok = 0;

crossovertries_limit = 10;
crossovertries_count = 1;

num_zones = size(h.f_array,1);
num_facs = size(h.f_array,2);

while ~constraints_ok && crossovertries_count <= crossovertries_limit
    
    %cpoints = cpoints(1:num_cpoints);
    
    cpoint1 = 1;
    cpoint2 = 1;
    cpoint3 = 1;
    while cpoint1 == cpoint2 || cpoint2 == cpoint3 || cpoint1 == cpoint3
        cpoint1 = floor(rand*(totalnum_allf_allSZ-1))+1;
        cpoint2 = floor(rand*(totalnum_allf_allSZ-1))+1;
        cpoint3 = floor(rand*(totalnum_allf_allSZ-1))+1;
        cpoints = sort([cpoint1 cpoint2 cpoint3]);
        cpoint1 = cpoints(1);
        cpoint2 = cpoints(2);
        cpoint3 = cpoints(3);
    end
    
    Q(:,1) = cat(1,P1(1:cpoint1,1),P2(cpoint1+1:cpoint2,1),P1(cpoint2+1:cpoint3,1),P2(cpoint3+1:end,1));
    Q(:,2) = cat(1,P2(1:cpoint1,1),P1(cpoint1+1:cpoint2,1),P2(cpoint2+1:cpoint3,1),P1(cpoint3+1:end,1));
    
    searchp_res1_1 = zeros(1,totalnum_allf_allSZ);
    before = 0;
    for z_num = 1:num_zones
        for f_num = 1:num_facs
            searchp_res1_1(before+1:before + h.f_array(z_num,f_num)) = ...
                pointdata{z_num,1}.pointslist(Q(before+1:before + h.f_array(z_num,f_num),1));
            before = before + h.f_array(z_num,f_num);
        end
    end
    
    searchp_res1_2 = zeros(1,totalnum_allf_allSZ);
    before = 0;
    for z_num = 1:num_zones
        for f_num = 1:num_facs
            searchp_res1_2(before+1:before + h.f_array(z_num,f_num)) = ...
                pointdata{z_num,1}.pointslist(Q(before+1:before + h.f_array(z_num,f_num),2));
            before = before + h.f_array(z_num,f_num);
        end
    end
    
    
    if size(unique(searchp_res1_1(1,1:totalnum_allf_allSZ)),2) ==  totalnum_allf_allSZ...
            && size(unique(searchp_res1_2(1,1:totalnum_allf_allSZ)),2) ==  totalnum_allf_allSZ
        
        if isempty(h.constraints_array)
            
            constraints_ok = 1;
            
            
        end
        
    else
        constraints_ok = 0;
    end
    
    crossovertries_count = crossovertries_count + 1;
    
end

end

