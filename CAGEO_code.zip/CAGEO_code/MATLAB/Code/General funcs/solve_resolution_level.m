function [P_global,objP_global,P_FCO,obj_FCO,...
    P_Pareto,obj_Pareto,time_global,...
    next_startP,next_startobj,...
    next_res_pointdata,...
    interrupt,lostime_global] = ...
    ...
    solve_resolution_level(n_obj,h,nextlevel,...
    current_res_pointdata,...
    startP,startobj,...
    is_final_res,timevec,algorithm,current_res)

next_res_pointdata = [];

constraints_array = h.constraints_array;

interrupt = 0;

f = 1/298.257223563;
a = 6378137;
latdist = vdist(h.lat,0,h.lat + 1/3600,0,a,f);
londist = vdist(h.lat,0,h.lat,1/3600,a,f);

P_global = [];
objP_global = [];
P_FCO = [];
obj_FCO = [];
P_Pareto = [];
obj_Pareto = [];
time_global = [];
next_startP = [];
next_startobj = [];

%%%%%carry_over_options
%%% 1 No carry over
%%% 2 All same
%%% 3 All same + all shake
if algorithm == 1
    carry_over_option = 1;
elseif algorithm == 2
    carry_over_option = 1;
elseif algorithm == 3
    carry_over_option = 1;
end

if algorithm == 1 || algorithm == 3
    if current_res == 12 || current_res == 6
        Pareto_threshold_perc = h.threshold/100;
        Pareto_threshold_count = h.threshold_count;
    else
        Pareto_threshold_perc = h.threshold_HR/100;
        Pareto_threshold_count = h.threshold_count_HR;
    end
    
    fixed_nsga_pop_size = h.psize;
    
    if isempty(startP)
        pop_size = fixed_nsga_pop_size;
    else
        if h.half_NSGA_pop == 1
            if carry_over_option == 2
                pop_size = 2*size(startP,2);
            elseif carry_over_option == 3
                pop_size = size(startP,2);
            end
        elseif h.half_NSGA_pop == 0
            if carry_over_option == 2
                pop_size = size(startP,2);
            elseif carry_over_option == 4
                pop_size = 2*size(startP,2);
            elseif carry_over_option == 5
                pop_size = size(startP,2);
            end
        end
    end
    parameters = [pop_size; 4; pop_size/2;...
        h.NSGA_CR;h.NSGA_MR; Pareto_threshold_perc; Pareto_threshold_count];
    if mod(parameters(1),2) ~= 0
        parameters(3) = (parameters(1) + 1)/2;
    end
    if algorithm == 3
        parameters(4) = h.HGA_CR;
        parameters(8) = h.HGA_GI;
        parameters(2) = 2;
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
elseif algorithm == 2
    if current_res == 12 || current_res == 6
        Pareto_threshold_perc = h.threshold/100;
        Pareto_threshold_count = h.threshold_count;
    else
        Pareto_threshold_perc = h.threshold_HR/100;
        Pareto_threshold_count = h.threshold_count_HR;
    end
    if carry_over_option == 1
        parameters = [1; h.GRIA_GI; Pareto_threshold_perc; Pareto_threshold_count];
    elseif carry_over_option == 2
        if ~isempty(startP)
            parameters = [size(startP,2); h.GRIA_GI; Pareto_threshold_perc; Pareto_threshold_count];
        else
            parameters = [h.psize; h.GRIA_GI; Pareto_threshold_perc; Pareto_threshold_count];
        end
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%
    if ~isempty(startP)
        parameters = [size(startP,2); h.GRIA_GI; Pareto_threshold_perc; Pareto_threshold_count];
    end
    %%%%%%%%%%%%%%%%%%%%%%%%
    
end

set(h.current_psize_display,'String',num2str(parameters(1)));
drawnow

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%GLOBAL OPTIMISATION NSGA/T&B
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if algorithm == 1
    [P_global,objP_global,...
        time_global,interrupt,lostime_global]...
        ...
        = NSGAII(n_obj,...
        current_res_pointdata,...
        parameters,...
        startP,startobj,h,timevec,current_res);
elseif algorithm == 2
    [P_global,objP_global,...
        time_global,interrupt,lostime_global]...
        ...
        = NSA(n_obj,...
        current_res_pointdata,...
        parameters,...
        startP,startobj,h,timevec,current_res);
elseif algorithm == 3
    [P_global,objP_global,...
        time_global,interrupt,lostime_global]...
        ...
        = hybrid(n_obj,...
        current_res_pointdata,...
        parameters,...
        startP,startobj,h,timevec,current_res);
end
if interrupt
    return
end
%updateplots('.r',n_obj,objP_global,h);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% f1_pdone_res1 = SZ1_pointslist(f1_pdone_res1);
% f2_pdone_res1 = SZ2_pointslist(f2_pdone_res1);

[F, front_size, ~, n_frnts] = partition_n_obj(objP_global,n_obj);

P_Pareto = P_global(:,F(1,1:front_size(1)));
obj_Pareto = objP_global(:,F(1,1:front_size(1)));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
P_FCO = [];
obj_FCO = [];
next_startP = [];
next_startobj = [];


next_res_pointdata= cell(size(h.f_array,1),1); 


if ~is_final_res
    P_FCO = P_global;
    obj_FCO = objP_global;
    
    [P_FCO,obj_FCO] = filter_front(P_FCO,obj_FCO);    
    
    before = 0;
    for z_num = 1:size(h.f_array,1)
        
        %zone_carriedoverstartpoints = [];
        
        num_facs = sum(h.f_array(z_num,:));
        
        zone_allcarriedoverpoints = P_global(before+1:before+num_facs,:);
        P_FCO(before+1:before+num_facs,:) = current_res_pointdata{z_num,1}.pointslist(P_FCO(before+1:before+num_facs,:));
        
        before = before + num_facs;
        
        zone_allcarriedoverpoints = current_res_pointdata{z_num,1}.pointslist(zone_allcarriedoverpoints);
        zone_allcarriedoverpoints(zone_allcarriedoverpoints == 0) = [];
        zone_allcarriedoverpoints = unique(zone_allcarriedoverpoints);
        
        zone_next_pointslist=[];
        zone_next_local_index=[];
        
        if sum(h.f_array(z_num,:)) > 0
            [ zone_next_pointslist, zone_next_local_index] = ...
                nextlevelpoints( zone_allcarriedoverpoints', h.zone_data{z_num,1}.feasible1,nextlevel,h.sizeTerrain1,h.ES);
            
        end
        next_res_pointdata{z_num,1}.pointslist = zone_next_pointslist;
        next_res_pointdata{z_num,1}.localindex = zone_next_local_index;

    end   
    
    if carry_over_option == 1
        next_startP = [];
        next_startobj = [];
    else
%         if algorithm == 1 || algorithm == 3
%             next_pop_size = pop_size;%2*size(P_global,2);
%         end
%         if carry_over_option == 2
%             %%%%%%%%%carry over exact same
%             
%             if algorithm == 1 || algorithm == 3
%                 if size(P_global,2) > next_pop_size
%                     [ carry_over_P, carry_over_objP,~,~, ~] = create_new_P( P_global,objP_global, n_obj, next_pop_size );
%                     [carry_over_P, carry_over_objP] = filter_front(carry_over_P, carry_over_objP);
%                     
%                     
%                     SZ1_carriedoverstartpoints = [];
%                     for row_num = 1:SZ1_n_f_toplace
%                         SZ1_carriedoverstartpoints = cat(2,SZ1_carriedoverstartpoints,carry_over_P(row_num,:));
%                     end
%                     SZ2_carriedoverstartpoints = [];
%                     for row_num = SZ1_n_f_toplace+1:SZ1_n_f_toplace+SZ2_n_f_toplace
%                         SZ2_carriedoverstartpoints = cat(2,SZ2_carriedoverstartpoints,carry_over_P(row_num,:));
%                     end
%                     
%                     
%                     next_startobj = carry_over_objP;
%                 else
%                     next_startobj = obj_FCO;
%                 end
%             else next_startobj = obj_FCO;
%             end
%             
%             SZ1_nextlevel_startlist = SZ1_pointslist(SZ1_carriedoverstartpoints);
%             for i = 1:size(SZ1_nextlevel_startlist,2)
%                 SZ1_nextlevel_startlist(1,i) = find(SZ1_next_pointslist == SZ1_nextlevel_startlist(1,i));
%             end
%             
%             SZ2_nextlevel_startlist = SZ2_pointslist(SZ2_carriedoverstartpoints);
%             for i = 1:size(SZ2_nextlevel_startlist,2)
%                 SZ2_nextlevel_startlist(1,i) = find(SZ2_next_pointslist == SZ2_nextlevel_startlist(1,i));
%             end
%             
%             next_startP = [];
%             for row_num = 1:SZ1_n_f_toplace
%                 next_startP = cat(1,next_startP,SZ1_nextlevel_startlist(1,(row_num-1)*(size(SZ1_nextlevel_startlist,2)/SZ1_n_f_toplace)+1 : row_num*(size(SZ1_nextlevel_startlist,2)/SZ1_n_f_toplace)));
%             end
%             for row_num = 1:SZ2_n_f_toplace
%                 next_startP = cat(1,next_startP,SZ2_nextlevel_startlist(1,(row_num-1)*(size(SZ2_nextlevel_startlist,2)/SZ2_n_f_toplace)+1 : row_num*(size(SZ2_nextlevel_startlist,2)/SZ2_n_f_toplace)));
%             end
% 
%         end
        
    end
    
end

