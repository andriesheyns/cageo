get_pareto_sites_all_runs

hold

load('run_1.mat','numruns');

for run_count = 1:numruns
    
    load(strcat('run_',num2str(run_count),'.mat'),'Pareto_obj_front');

    plot(Pareto_obj_front(1,:),Pareto_obj_front(2,:),'.','MarkerSize',10)

end

axis square
grid on