function interrupt = execute_runs(h,algorithm)

rng('shuffle');

if ispc
    slashchar = '\';
else
    slashchar = '/';
end
interrupt = 0;

allpointsfinalsequence_global = [];

n_obj = h.n_obj;

time = clock;
timefolder = strcat(num2str(time(1)),'_',num2str(time(2)),'_',num2str(time(3)),'_',num2str(time(4)),'_',num2str(time(5)));
if algorithm == 1
    algorithmcat = strcat('NSGA',slashchar);
    num_runs = h.NSGA_numruns;
elseif algorithm == 2
    algorithmcat = strcat('AMOEBA',slashchar);
    num_runs = h.GRIA_numruns;
elseif algorithm == 3
    algorithmcat = strcat('HGA',slashchar);
    num_runs = h.HGA_numruns;
end
set(h.total_number_runs_display,'String',num_runs);

binsdir = h.binsdir;

alldoresolutions = h.resolutions.*h.doresolutions;
alldoresolutions(find(alldoresolutions == 0)) = [];
doresolutions = alldoresolutions;
startres = max(doresolutions);

totaltime = tic;

% test = h.constraints_tzp1_array
% test = h.constraints_tzp2_array
% pause

for run_counter = 1:num_runs
    
    runtime = tic;
    timevec = [totaltime runtime];
    
    plotdata12 = [];
    plotdata6 = [];
    plotdata3 = [];
    plotdata1 = [];
    
    lostime12_global = [0 0];
    lostime6_global = [0 0];
    lostime3_global = [0 0];
    lostime1_global = [0 0];
    
    time12_global = 0;
    time6_global = 0;
    time3_global = 0;
    time1_global = 0;
    
    P_global12 = [];
    P_global6 = [];
    P_global3 = [];
    P_global1 = [];
    
    objP_global12 = [];
    objP_global6 = [];
    objP_global3 = [];
    objP_global1 = [];
    
    startP6 = [];
    startP3 = [];
    startP1 = [];
    startobj6 = [];
    startobj3 = [];
    startobj1 = [];
    
    for i = 1:size(h.zone_data,1)
        run_zone_data{i,1}.pointslist12 = h.zone_data{i,1}.feasible12;
        run_zone_data{i,1}.localindex12 = h.zone_data{i,1}.localindex12;
        
        current_res_pointdata{i,1}.pointslist = h.zone_data{i,1}.feasible12;
        current_res_pointdata{i,1}.localindex = h.zone_data{i,1}.localindex12;
        
        run_zone_data{i,1}.pointslist6 = [];
        run_zone_data{i,1}.localindex6 = [];
        
        run_zone_data{i,1}.pointslist3 = [];
        run_zone_data{i,1}.localindex3 = [];
        
        run_zone_data{i,1}.pointslist1 = [];
        run_zone_data{i,1}.localindex1 = [];
        
    end
    
    %     f1_pdone_12_res1 = [];
    %     f2_pdone_12_res1 = [];
    %     f1_pdone_6_res1 = [];
    %     f2_pdone_6_res1 = [];
    %     f1_pdone_3_res1 = [];
    %     f2_pdone_3_res1 = [];
    %     f1_pdone_1_res1 = [];
    %     f2_pdone_1_res1 = [];
    
    final_res = 0;
    
    doresolutions = alldoresolutions;
    
    set(h.current_run_number_display,'String',run_counter);
    drawnow
    
    %total_num = size(h.IZ1_interest1,2);%sizeTerrain1(1)*h.sizeTerrain1(2);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if ~isempty(find(doresolutions == 12))
        doresolutions(1) = [];
        if ~isempty(doresolutions)
            if doresolutions(1) == 6
                nextres = 6;
            elseif doresolutions(1) == 3
                nextres = 3;
            else
                nextres = 1;
            end
        else
            final_res = 1;
            nextres = 1;
        end
        
        plotcolour = '.c';
        %         [rows,cols] = ind2sub(h.sizeTerrain1,cat(2,h.SZ1_feasible12,h.SZ2_feasible12));
        %         if h.doplots
        %             axes(h.candidate_locations);
        %             plotdata12 = plot(cols,rows,plotcolour,'MarkerSize',5);
        %         end
        set(h.current_resolution_display,'String',12);
        drawnow
        [P_global12,objP_global12,P_FCO12,obj_FCO12,P_Pareto12,obj_Pareto12,...
            time12_global,...
            nextstartP,nextstartobj,...
            next_res_pointdata,...
            interrupt,lostime12_global] = ...
            ...
            solve_resolution_level(n_obj,h,nextres,...
            current_res_pointdata,...
            [],[],final_res,timevec,algorithm,12);
        if interrupt
            return
        end
        
        if h.doplots
            updateplots(plotcolour,n_obj,obj_Pareto12,h);
        end
        
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if ~isempty(find(doresolutions == 6))
        doresolutions(1) = [];
        if ~isempty(doresolutions)
            if doresolutions(1) == 3
                nextres = 3;
            else
                nextres = 1;
            end
        else
            final_res = 1;
            nextres = 1;
        end
        if startres == 6
            random_start = get(h.random_start,'Value');
            if random_start == 0
                for i = 1:size(h.zone_data,1)
                    run_zone_data{i,1}.pointslist6 = h.zone_data{i,1}.feasible6;
                    run_zone_data{i,1}.localindex6 = h.zone_data{i,1}.localindex6;
                    
                    current_res_pointdata{i,1}.pointslist = h.zone_data{i,1}.feasible6;
                    current_res_pointdata{i,1}.localindex = h.zone_data{i,1}.localindex6;
                    
                end
                
                startP6 = [];
                startobj6 = [];
            else
                test = h.psize*sum(sum(h.f_array))*4
                random_points_arr = unique(randperm(size(h.zone_data{1,1}.feasible1,2),h.psize*sum(sum(h.f_array))*4));
                
                %determine viewshed percentages of the selected sites
                %choose best half
                
                %%%%%
                zone_vis = zeros(h.sizeTerrain1);
                zone_vis(h.iz_data{1,1}.interest1) = 1;
                size_matrix = zeros(size(random_points_arr));
                for f_num = 1:size(random_points_arr,2)
                    f_num
                    vismatrix_1 = zeros(h.sizeTerrain1);
                    [Visarray,extent,~] = read_visarray_screen_from_bin(h.binsdir,h.zone_data{1,1}.feasible1(random_points_arr(f_num)),h.LOSterrain,1,15);
                    rowmin = extent(1);
                    rowdiff = extent(2);
                    colmin = extent(3);
                    coldiff = extent(4);
                    Visarray((coldiff+1)*(rowdiff+1)+1:end) = [];
                    vismatrix_1(rowmin:rowmin+rowdiff,colmin:colmin+coldiff) = vismatrix_1(rowmin:rowmin+rowdiff,colmin:colmin+coldiff) + reshape(Visarray,[coldiff+1 rowdiff+1])';
                    vismatrix_1 = zone_vis.*vismatrix_1;
                    size_matrix(1,f_num) = size(find(vismatrix_1 > 0),1);
                end
                result_matrix = cat(1,size_matrix,random_points_arr);
                out = sortrows(result_matrix',1)';
                random_points_arr = out(2,h.psize*sum(sum(h.f_array))*2+1:end);
                random_points_arr = sort(random_points_arr);
                
                clear result_matrix
                clear vismatrix_1
                clear Visarray
                clear zone_vis
                
                %%%%%%%
                
                run_zone_data{1,1}.pointslist3 = h.zone_data{1,1}.feasible1(random_points_arr);
                run_zone_data{1,1}.localindex3 = h.zone_data{1,1}.localindex1(random_points_arr);
                
                current_res_pointdata{1,1}.pointslist = h.zone_data{1,1}.feasible1(random_points_arr);
                current_res_pointdata{1,1}.localindex = h.zone_data{1,1}.localindex1(random_points_arr);
                
                %end
            end
            
        else
            for i = 1:size(h.zone_data,1)
                run_zone_data{i,1}.pointslist6 = next_res_pointdata{i,1}.pointslist;
                run_zone_data{i,1}.localindex6 = next_res_pointdata{i,1}.localindex;
                
                current_res_pointdata{i,1}.pointslist = next_res_pointdata{i,1}.pointslist;
                current_res_pointdata{i,1}.localindex = next_res_pointdata{i,1}.localindex;
            end
            startP6 = nextstartP;
            startobj6 = nextstartobj;
        end
        
        %         plotcolour = '.m';
        %         [rows,cols] = ind2sub(h.sizeTerrain1,cat(2,SZ1_pointslist6,SZ2_pointslist6));
        %         %         if h.doplots
        %         %             axes(h.candidate_locations);
        %         %             plotdata6 = plot(cols,rows,plotcolour,'MarkerSize',5);
        %         %         end
        set(h.current_resolution_display,'String',6);
        drawnow
        [P_global6,objP_global6,P_FCO6,obj_FCO6,P_Pareto6,obj_Pareto6,...
            time6_global,...
            nextstartP,nextstartobj,...
            next_res_pointdata,interrupt,...
            lostime6_global] = ...
            ...
            solve_resolution_level(n_obj,h,nextres,...
            current_res_pointdata,...
            startP6,startobj6,final_res,timevec,algorithm,6);
        if interrupt
            return
        end
        if h.doplots
            updateplots(plotcolour,n_obj,obj_Pareto6,h);
        end
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if ~isempty(find(doresolutions == 3))
        doresolutions(1) = [];
        nextres = 1;
        if startres == 3

                for i = 1:size(h.zone_data,1)
                    run_zone_data{i,1}.pointslist3 = h.zone_data{i,1}.feasible3;
                    run_zone_data{i,1}.localindex3 = h.zone_data{i,1}.localindex3;
                    
                    current_res_pointdata{i,1}.pointslist = h.zone_data{i,1}.feasible3;
                    current_res_pointdata{i,1}.localindex = h.zone_data{i,1}.localindex3;
                    
                end
                
                startP3 = [];
                startobj3 = [];
            
        else
            for i = 1:size(h.zone_data,1)
                run_zone_data{i,1}.pointslist3 = next_res_pointdata{i,1}.pointslist;
                run_zone_data{i,1}.localindex3 = next_res_pointdata{i,1}.localindex;
                
                current_res_pointdata{i,1}.pointslist = next_res_pointdata{i,1}.pointslist;
                current_res_pointdata{i,1}.localindex = next_res_pointdata{i,1}.localindex;
            end
            startP3 = nextstartP;
            startobj3 = nextstartobj;
        end
        if isempty(doresolutions)
            final_res = 1;
        end
        
        %         plotcolour = '.b';
        %         [rows,cols] = ind2sub(h.sizeTerrain1,cat(2,SZ1_pointslist3,SZ2_pointslist3));
        %         %         if h.doplots
        %         %             axes(h.candidate_locations);
        %         %             plotdata3 = plot(cols,rows,plotcolour,'MarkerSize',5);
        %         %         end
        set(h.current_resolution_display,'String',3);
        drawnow
        [P_global3,objP_global3,P_FCO3,obj_FCO3,P_Pareto3,obj_Pareto3,...
            time3_global,...
            nextstartP,nextstartobj,...
            next_res_pointdata,interrupt,...
            lostime3_global] = ...
            ...
            solve_resolution_level(n_obj,h,nextres,...
            current_res_pointdata,...
            startP3,startobj3,final_res,timevec,algorithm,3);
        if interrupt
            return
        end
        
        if h.doplots
            updateplots(plotcolour,n_obj,obj_Pareto3,h);
        end
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if ~isempty(find(doresolutions == 1))
        if startres == 1
            for i = 1:size(h.zone_data,1)
                run_zone_data{i,1}.pointslist1 = h.zone_data{i,1}.feasible1;
                run_zone_data{i,1}.localindex1 = h.zone_data{i,1}.localindex1;
                
                current_res_pointdata{i,1}.pointslist = h.zone_data{i,1}.feasible1;
                current_res_pointdata{i,1}.localindex = h.zone_data{i,1}.localindex1;
                
            end
            
            startP1 = [];
            startobj1 = [];
        else
            for i = 1:size(h.zone_data,1)
                run_zone_data{i,1}.pointslist1 = next_res_pointdata{i,1}.pointslist;
                run_zone_data{i,1}.localindex1 = next_res_pointdata{i,1}.localindex;
                
                current_res_pointdata{i,1}.pointslist = next_res_pointdata{i,1}.pointslist;
                current_res_pointdata{i,1}.localindex = next_res_pointdata{i,1}.localindex;
            end
            startP1 = nextstartP;
            startobj1 = nextstartobj;
        end
        final_res = 1;
        nextres = 0;
        
        %         plotcolour = '.r';
        %         [rows,cols] = ind2sub(h.sizeTerrain1,cat(2,SZ1_pointslist1,SZ2_pointslist1));
        %         %         if h.doplots
        %         %             axes(h.candidate_locations);
        %         %             plotdata1 = plot(cols,rows,plotcolour,'MarkerSize',5);
        %         %         end
        set(h.current_resolution_display,'String',1);
        drawnow
        [P_global1,objP_global1,P_FCO1,obj_FCO1,P_Pareto1,obj_Pareto1,...
            time1_global,...
            nextstartP,nextstartobj,...
            next_res_pointdata,interrupt,...
            lostime1_global] = ...
            ...
            solve_resolution_level(n_obj,h,nextres,...
            current_res_pointdata,...
            startP1,startobj1,final_res,timevec,algorithm,1);
        if interrupt
            return
        end
        
        %         if h.doplots
        %             updateplots(plotcolour,n_obj,obj_Pareto1,h);
        %         end
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %     allpointsfinal_global = [];
    %
    %     if ~isempty(find(alldoresolutions == 12))
    %         allpointsfinal_global = cat(2,allpointsfinal_global,...
    %             f1_pdone_12_res1',f2_pdone_12_res1');
    %         allpointsfinal_global = unique(allpointsfinal_global);
    %     end
    %
    %     if ~isempty(find(alldoresolutions == 6))
    %         allpointsfinal_global = cat(2,allpointsfinal_global,...
    %             f1_pdone_6_res1',f2_pdone_6_res1');
    %         allpointsfinal_global = unique(allpointsfinal_global);
    %     end
    %
    %     if ~isempty(find(alldoresolutions == 3))
    %         allpointsfinal_global = cat(2,allpointsfinal_global,...
    %             f1_pdone_3_res1',f2_pdone_3_res1');
    %         allpointsfinal_global = unique(allpointsfinal_global);
    %     end
    %
    %     if ~isempty(find(alldoresolutions == 1))
    %         allpointsfinal_global = cat(2,allpointsfinal_global,...
    %             f1_pdone_1_res1',f2_pdone_1_res1');
    %         allpointsfinal_global = unique(allpointsfinal_global);
    %     end
    
    
    %     prevdone_SZ1 = zeros(1,size(h.SZ1_feasible1,2));
    %     if ~isempty(allpointsfinalsequence_global)
    %         for point = 1:size(allpointsfinalsequence_global,2)
    %             prevpoint = find(h.SZ1_feasible1 == allpointsfinalsequence_global(point));
    %             prevdone_SZ1(1,prevpoint) = 1;
    %         end
    %     end
    %     currentdone_SZ1 = zeros(1,size(h.SZ1_feasible1,2));
    %     for point = 1:size(allpointsfinal_global,2)
    %         currentpoint = find(h.SZ1_feasible1 == allpointsfinal_global(point));
    %         currentdone_SZ1(1,currentpoint) = 1;
    %     end
    %
    %     sumdone_SZ1 = currentdone_SZ1-prevdone_SZ1;
    %     allpointsnew_SZ1 = h.SZ1_feasible1(find(sumdone_SZ1 == 1));
    %
    %     prevdone_SZ2 = zeros(1,size(h.SZ2_feasible1,2));
    %     if ~isempty(allpointsfinalsequence_global)
    %         for point = 1:size(allpointsfinalsequence_global,2)
    %             prevpoint = find(h.SZ2_feasible1 == allpointsfinalsequence_global(point));
    %             prevdone_SZ2(1,prevpoint) = 1;
    %         end
    %     end
    %     currentdone_SZ2 = zeros(1,size(h.SZ2_feasible1,2));
    %     for point = 1:size(allpointsfinal_global,2)
    %         currentpoint = find(h.SZ2_feasible1 == allpointsfinal_global(point));
    %         currentdone_SZ2(1,currentpoint) = 1;
    %     end
    %
    %     sumdone_SZ2 = currentdone_SZ2-prevdone_SZ2;
    %     allpointsnew_SZ2 = h.SZ2_feasible1(find(sumdone_SZ2 == 1));
    
    %     blankdone = zeros(h.sizeTerrain1);
    %     prevdone_SZ1 = zeros(1,size(h.SZ1_feasible1,2));
    %     prevdone_SZ2 = zeros(1,size(h.SZ2_feasible1,2));
    %     prevdone_SZ1 = zeros(1,size(h.SZ1_feasible1,2));
    %     prevdone_SZ2 = zeros(1,size(h.SZ2_feasible1,2));
    %     allpointsnew_SZ1 = zeros(1,size(h.SZ1_feasible1,2));
    %     allpointsnew_SZ2 = zeros(1,size(h.SZ2_feasible1,2));
    %
    %     blankdone(allpointsfinalsequence_global) = 1;
    %     prevdone_SZ1 = blankdone(h.SZ1_feasible1);
    %     prevdone_SZ2 = blankdone(h.SZ2_feasible1);
    %
    %     blankdone(:,:) = 0;
    %
    %     blankdone(allpointsfinal_global) = 1;
    %     currentdone_SZ1 = blankdone(h.SZ1_feasible1);
    %     currentdone_SZ2 = blankdone(h.SZ2_feasible1);
    %
    %     sumdone_SZ1 = currentdone_SZ1-prevdone_SZ1;
    %     allpointsnew_SZ1 = h.SZ1_feasible1(find(sumdone_SZ1 == 1));
    %
    %     sumdone_SZ2 = currentdone_SZ2-prevdone_SZ2;
    %     allpointsnew_SZ2 = h.SZ2_feasible1(find(sumdone_SZ2 == 1));
    
    % % %     %timenewpoints = sum(h.alltime(allpointsnew));
    lostime12 = lostime12_global(1);
    lostime6 = lostime6_global(1);
    lostime3 = lostime3_global(1);
    lostime1 = lostime1_global(1);
    lostime = lostime12 + lostime6 + lostime3 + lostime1;
    filereadtime12 = lostime12_global(2);
    filereadtime6 = lostime6_global(2);
    filereadtime3 = lostime3_global(2);
    filereadtime1 = lostime1_global(2);
    filereadtime = filereadtime12 + filereadtime6 + filereadtime3 + filereadtime1;
    % % %
    % % %     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % % %     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % % %     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % % %
    %     allpointsfinalsequence_global = cat(2,allpointsfinalsequence_global,allpointsfinal_global);
    %     allpointsfinalsequence_global = unique(allpointsfinalsequence_global);
    
    P_res1 = P_global1;
    startP_res1 = startP1;
    
    if ~isempty(P_global1)
        
        before = 0;
        for z_num = 1:size(h.f_array,1)
            num_facs = sum(h.f_array(z_num,:));
            P_res1(before+1:before+num_facs,:) = run_zone_data{z_num,1}.pointslist1(P_global1(before+1:before+num_facs,:));
            if ~isempty(startP1)
                startP_res1(before+1:before+num_facs,:) = run_zone_data{z_num,1}.pointslist1(startP1(before+1:before+num_facs,:));
            end
            before = before + num_facs;
        end
    end
    
    P_res3 = P_global3;
    startP_res3 = startP3;
    
    if ~isempty(P_global3)
        
        before = 0;
        for z_num = 1:size(h.f_array,1)
            num_facs = sum(h.f_array(z_num,:));
            P_res3(before+1:before+num_facs,:) = run_zone_data{z_num,1}.pointslist3(P_global3(before+1:before+num_facs,:));
            if ~isempty(startP3)
                startP_res3(before+1:before+num_facs,:) = run_zone_data{z_num,1}.pointslist3(startP3(before+1:before+num_facs,:));
            end
            before = before + num_facs;
        end
    end
    
    P_res6 = P_global6;
    startP_res6 = startP6;
    
    if ~isempty(P_global6)
        
        before = 0;
        for z_num = 1:size(h.f_array,1)
            num_facs = sum(h.f_array(z_num,:));
            P_res6(before+1:before+num_facs,:) = run_zone_data{z_num,1}.pointslist6(P_global6(before+1:before+num_facs,:));
            if ~isempty(startP6)
                startP_res6(before+1:before+num_facs,:) = run_zone_data{z_num,1}.pointslist6(startP6(before+1:before+num_facs,:));
            end
            before = before + num_facs;
        end
    end
    
    P_res12 = P_global12;
    
    if ~isempty(P_global12)
        
        before = 0;
        for z_num = 1:size(h.f_array,1)
            num_facs = sum(h.f_array(z_num,:));
            P_res12(before+1:before+num_facs,:) = run_zone_data{z_num,1}.pointslist12(P_global12(before+1:before+num_facs,:));
            before = before + num_facs;
        end
    end
    
    if algorithm == 1 || algorithm == 3
        if ~isempty(P_global12)
            [~, ~, prank, ~] = partition_n_obj(objP_global12,n_obj);
            P_Pareto_res12 = P_res12(:,find(prank == 1));
            objP_Pareto_res12 = objP_global12(:,find(prank == 1));
        else
            P_Pareto_res12 = [];
            objP_Pareto_res12 = [];
        end
        if ~isempty(P_global6)
            [~, ~, prank, ~] = partition_n_obj(objP_global6,n_obj);
            P_Pareto_res6 = P_res6(:,find(prank == 1));
            objP_Pareto_res6 = objP_global6(:,find(prank == 1));
        else
            P_Pareto_res6 = [];
            objP_Pareto_res6 = [];
        end
        if ~isempty(P_global3)
            [~, ~, prank, ~] = partition_n_obj(objP_global3,n_obj);
            P_Pareto_res3 = P_res3(:,find(prank == 1));
            objP_Pareto_res3 = objP_global3(:,find(prank == 1));
        else
            P_Pareto_res3 = [];
            objP_Pareto_res3 = [];
        end
        if ~isempty(P_global1)
            [~, ~, prank, ~] = partition_n_obj(objP_global1,n_obj);
            P_Pareto_res1 = P_res1(:,find(prank == 1));
            objP_Pareto_res1 = objP_global1(:,find(prank == 1));
        else
            P_Pareto_res1 = [];
            objP_Pareto_res1 = [];
        end
    elseif algorithm == 2
        P_Pareto_res12 = P_res12;
        objP_Pareto_res12 = objP_global12;
        P_Pareto_res6 = P_res6;
        objP_Pareto_res6 = objP_global6;
        P_Pareto_res3 = P_res3;
        objP_Pareto_res3 = objP_global3;
        P_Pareto_res1 = P_res1;
        objP_Pareto_res1 = objP_global1;
    end
    
    %     if run_counter < num_runs
    %         delete(plotdata12);
    %         delete(plotdata6);
    %         delete(plotdata3);
    %         delete(plotdata1);
    %     end
    % % %
    
    dirtext = timefolder;
    %     dirtext = 'kruger';
    
    if run_counter == 1
        created = 0;
        folder_set = 1;
        while ~created
            if ~(exist(strcat(h.savedir,algorithmcat,slashchar,dirtext,'_dir_set_',num2str(folder_set))) == 7)
                mkdir(strcat(h.savedir,algorithmcat,slashchar,dirtext,'_dir_set_',num2str(folder_set)));
                created = 1;
            else
                folder_set = folder_set + 1;
            end
        end
    end
    
    savesize = h.sizeTerrain1;
    %     IZ1_interest1 = h.IZ1_interest1;
    %     IZ2_interest1 = h.IZ2_interest1;
    binsdir = h.binsdir;
    objectives = h.objectives_array;
    constraints = h.constraints_array;
    
    Pareto_obj_front = objP_Pareto_res1;
    Pareto_solutions = P_Pareto_res1;
    run = run_counter;
    numruns = num_runs;
    
    save(strcat(h.savedir,algorithmcat,dirtext,...
        '_dir_set_',num2str(folder_set),slashchar,'run_',num2str(run_counter),'.mat'),...
        'Pareto_obj_front','Pareto_solutions','numruns','run');
    
    clearvars -except dirtext algorithm num_runs run_counter allpointsfinalsequence_global distconstraint secondaryvisconstr h timefolder n_obj alldoresolutions startres totaltime interrupt algorithmcat lostime slashchar folder_set
    
end
toc(totaltime)

end





