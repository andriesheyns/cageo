function [Pnew] = mutation_local_v2(P,...
    zone_n_locs,pointdata,...
    latdist,londist, ...
    h,current_res)

%disp('local mutation')

constraints_ok = 0;

totalnum_allf_allSZ = sum(sum(h.f_array));

num_zones = size(h.f_array,1);
num_facs = size(h.f_array,2);
new_zone = 0;
new_type = 0;

all_constraint_facs_array = sum(h.constraints_tzp1_array,3);
all_constraint_facs_array2 = sum(h.constraints_tzp2_array,3);

max_tries = 5;
try_count = 1;
while ~constraints_ok && try_count <= max_tries
    
    Pnew = P;
    
    mfacility =floor(rand*totalnum_allf_allSZ) +1;
    
    before = 0;
    for z_num = 1:num_zones
        for f_num = 1:num_facs
            if any(mfacility == before+1:before+sum(h.f_array(z_num,f_num)))
                %Pnew(mfacility,1) = floor(rand*zone_n_locs(z_num)) +1;
                mfacility_res1 = pointdata{z_num,1}.pointslist(Pnew(mfacility));
                [mfacility_row,mfacility_col] = ind2sub(h.sizeTerrain1,mfacility_res1);
                
                %                 test = pointdata{z_num,1}.pointslist
                %                 pause
                %                 test = pointdata{z_num,1}.localindex
                %                 pause
                %                 pointdata{z_num,1}.pointslist(Pnew(mfacility))
                %                 pointdata{z_num,1}.localindex(Pnew(mfacility))
                %                 Pnew
                %                 pause
                
                mutation_done = 0;
                new_span = 5;
                
%                 newpointrow_span = mfacility_row-new_span*current_res: current_res: mfacility_row+new_span*current_res;
%                 newpointcol_span = mfacility_col-new_span*current_res: current_res:mfacility_col+new_span*current_res;
%                 
%                 for i = 1:size(newpointrow_span,2);
%                     for j = 1:size(newpointcol_span,2)
%                         newpoints_rows = cat(2,newpoints_rows,newpointrow_span(i));
%                         newpoints_cols = cat(2,newpoints_cols,newpointcol_span(j));
%                     end
%                 end
%                 remove = find(newpoints_rows <= 0);
%                 remove = cat(2,remove,find(newpoints_cols <= 0));
%                 remove = cat(2,remove,find(newpoints_rows > h.sizeTerrain1(1)));
%                 remove = cat(2,remove,find(newpoints_cols > h.sizeTerrain1(2)));
%                 
%                 remove = unique(remove);
%                 newpoints_rows(remove) = [];
%                 newpoints_cols(remove) = [];
%                 
%                 neighbour_points = sub2ind(h.sizeTerrain1,newpoints_rows,newpoints_cols);
                local_tries = 1;
                local_tries_max = 5;
                while ~mutation_done && local_tries <= local_tries_max
                    newpoint_row = mfacility_row + (floor(rand*(2*new_span + 1)) - new_span)*current_res;
                    newpoint_col = mfacility_col + (floor(rand*(2*new_span + 1)) - new_span)*current_res;
                    if  newpoint_row >= 1 && newpoint_col >= 1 &&...
                            newpoint_row <= h.sizeTerrain1(1) && newpoint_col <= h.sizeTerrain1(2)...
                                                    
                        newpointindex = sub2ind(h.sizeTerrain1,newpoint_row,newpoint_col);
                        
                        if any(newpointindex == pointdata{z_num,1}.pointslist)
                            Pnew(mfacility,1) = find(pointdata{z_num,1}.pointslist == newpointindex);
                            mutation_done = 1;
                        end
                        
                    end
                    local_tries = local_tries + 1;
                    
                end
                
                new_zone = z_num;
                new_type = f_num;
            end
            before = before+sum(h.f_array(z_num,f_num));
        end
    end
    
    Pnew_res1 = zeros(1,totalnum_allf_allSZ);
    before = 0;
    for z_num = 1:num_zones
        for f_num = 1:num_facs
            Pnew_res1(before+1:before + h.f_array(z_num,f_num)) = ...
                pointdata{z_num,1}.pointslist(Pnew(before+1:before + h.f_array(z_num,f_num)));
            before = before + h.f_array(z_num,f_num);
        end
    end
    
    if isempty(h.constraints_array)
        
        if size(unique(Pnew_res1(1,1:totalnum_allf_allSZ)),2) ==  totalnum_allf_allSZ
            
            constraints_ok = 1;
            
        else
            
            constraints_ok = 0;
            
        end
        
    else
        
        if size(unique(Pnew_res1(1,1:totalnum_allf_allSZ)),2) ==  totalnum_allf_allSZ
            
            if all_constraint_facs_array(new_zone,new_type) > 0 || all_constraint_facs_array2(new_zone,new_type) > 0
                constraint_num = 1;
                crit_val_ok = 1;
                
                while constraint_num <= size(h.constraints_array,1)  && crit_val_ok
                    
                    if h.constraints_tzp1_array(new_zone,new_type,constraint_num) > 0  || ...
                            (h.constraints_array(constraint_num,2) == 1 && h.constraints_tzp2_array(new_zone,new_type,constraint_num) > 0)
                        
                        if h.constraints_array(constraint_num,2) == 0
                            
                            %crit_value = h.zone_data{new_zone,1}.criteria{h.constraints_array(constraint_num,3)}(Pnew(mfacility));
                            crit_value = h.zone_data{new_zone,1}.criteria{h.constraints_array(constraint_num,3)}(pointdata{new_zone,1}.localindex(Pnew(mfacility)));
                            
                            if h.constraints_array(constraint_num,1) == 1
                                
                                if crit_value < h.constraints_array(constraint_num,8)
                                    crit_val_ok = 0;
                                end
                            elseif h.constraints_array(constraint_num,1) == 2
                                if crit_value > h.constraints_array(constraint_num,8)
                                    crit_val_ok = 0;
                                end
                            end
                            
                        else
                            
                            
                            
                            con_sites1_index = zeros(1,totalnum_allf_allSZ);
                            con_before = 0;
                            for z_con_num = 1:size(h.f_array,1)
                                for f_con_num = 1:size(h.f_array,2)
                                    if h.constraints_tzp1_array(z_con_num,f_con_num,constraint_num) == 1
                                        con_sites1_index(1,con_before+1:con_before+h.f_array(z_con_num,f_con_num)) = 1;
                                    end
                                    con_before = con_before+h.f_array(z_con_num,f_con_num);
                                end
                            end
                            con_sites1 = Pnew_res1.*con_sites1_index;
                            con_sites1 = con_sites1(find(con_sites1 > 0));
                            
                            con_sites2_index = zeros(1,totalnum_allf_allSZ);
                            con_before = 0;
                            for z_con_num = 1:size(h.f_array,1)
                                for f_con_num = 1:size(h.f_array,2)
                                    if h.constraints_tzp2_array(z_con_num,f_con_num,constraint_num) == 1
                                        con_sites2_index(1,con_before+1:con_before+h.f_array(z_con_num,f_con_num)) = 1;
                                    end
                                    con_before = con_before+h.f_array(z_con_num,f_con_num);
                                end
                            end
                            con_sites2 = Pnew_res1.*con_sites2_index;
                            con_sites2 = con_sites2(find(con_sites2 > 0));
                            
                            [crit_val_ok] = check_dist_groups(con_sites1,...
                                con_sites2,latdist,londist,...
                                h.sizeTerrain1,h.constraints_array(constraint_num,:));
                            
                            
                            
                        end
                        
                        if crit_val_ok
                            constraint_num = constraint_num + 1;
                        end
                        
                    else
                        constraint_num = constraint_num + 1;
                    end
                    
                end
                
                constraints_ok = crit_val_ok;
                
            else
                constraints_ok = 1;
            end
            
        else
            constraints_ok = 0;
        end
        
    end
    try_count = try_count + 1;
end

if ~constraints_ok
    Pnew = P;
end

end
