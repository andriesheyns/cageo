function cd = crowding_distance_n_obj(p_size,n_obj,obj)

cd=zeros(1,p_size);
%p_size=size(P,2);

for h=1:n_obj
    
    sorted_obj=sortrows(obj',h)';  %%%%%%% IMPORTANT: what to do if there is a tie????
    
    dont_consider = find(sorted_obj(h,:) == 99999999);
    if ~isempty(dont_consider)
        sorted_obj(:,dont_consider) = [];
    end
    
    if ~isempty(sorted_obj)
        
        cd(sorted_obj(n_obj+1,1))=Inf;
        cd(sorted_obj(n_obj+1,size(sorted_obj,2)))=Inf;
        for i=2:size(sorted_obj,2)-1
            if ~((sorted_obj(h,i+1)-sorted_obj(h,i-1)) == 0 &&...
                    (sorted_obj(h,size(sorted_obj,2))-sorted_obj(h,1)) == 0)
                cd(sorted_obj(n_obj+1,i))=cd(sorted_obj(n_obj+1,i))+...
                    (sorted_obj(h,i+1)-sorted_obj(h,i-1))/(sorted_obj(h,size(sorted_obj,2))-sorted_obj(h,1));
            end
        end
        
    end
    
end

end
