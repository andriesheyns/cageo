function [ pointsindex, local_index_list ] = nextlevelpoints( selected_points, ...
    SZ_feasible_points_max_level, next_res,max_ref_size,new_span )

[highres_rows,highres_cols] = ind2sub(max_ref_size,selected_points);

max_res_span = next_res*new_span;

newpoints_rows = [];
newpoints_cols = [];
for point = 1: size(selected_points,2)
    
    newpointrow_span = highres_rows(point)-max_res_span: next_res: highres_rows(point)+max_res_span;
    newpointcol_span = highres_cols(point)-max_res_span: next_res:highres_cols(point)+max_res_span;
       
    for i = 1:size(newpointrow_span,2);
        for j = 1:size(newpointcol_span,2)
            newpoints_rows = cat(2,newpoints_rows,newpointrow_span(i));
            newpoints_cols = cat(2,newpoints_cols,newpointcol_span(j));
        end
    end       
end

remove = find(newpoints_rows <= 0);
remove = cat(2,remove,find(newpoints_cols <= 0));
remove = cat(2,remove,find(newpoints_rows > max_ref_size(1)));
remove = cat(2,remove,find(newpoints_cols > max_ref_size(2)));

remove = unique(remove);
newpoints_rows(remove) = [];
newpoints_cols(remove) = [];

pointsindex = sub2ind(max_ref_size,newpoints_rows,newpoints_cols);

pointsmatrix = zeros(max_ref_size);
feasiblematrix = zeros(max_ref_size);
feasiblematrix(SZ_feasible_points_max_level) = 1;
pointsmatrix(pointsindex) = 1;

pointsmatrix = pointsmatrix.*feasiblematrix;
pointsindex = find(pointsmatrix == 1)';

local_index_list = zeros(1,size(pointsindex,2));
for point = 1: size(local_index_list,2)
    local_index = find(SZ_feasible_points_max_level == pointsindex(point));
    local_index_list(point) = local_index;
end