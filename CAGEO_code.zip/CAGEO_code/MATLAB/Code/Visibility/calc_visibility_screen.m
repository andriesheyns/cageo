function [pointsresultsformatted,extentpass] = calc_visibility_screen(directory,pointnumber,LOSterrain,screen_m)

%load('/sysadm/theonering/Desktop/PhD Matlab/MatlabGUI/Krugerdata/KrugerVISsource.mat');
%load('/sysadm/theonering/Desktop/PhD Matlab/MatlabGUI/Malmesburydata/MalmesburyVISsource.mat');
%load('C:\Users\Andries\Desktop\Current GUI\Malmesburydata\MalmesburyVISsource.mat');
%load('C:\Users\Andries\Desktop\Current GUI\Krugerdata\KrugerVISsource.mat');
%load('/home/andries/Desktop/Thesis/Current GUI/Krugerdata/KrugerVISsource.mat');
%load('/home/andries/Desktop/Thesis/Current GUI/Malmesburydata/MalmesburyVISsource.mat');
 
if ispc
    slashchar = '\';
else
    slashchar = '/';
end

load(strcat(directory,'facility_data.mat')); 

% length = size(index_IZ,2);
% stringtofile = zeros(1,length);

rangeextenty = ceil(radius/latdist);
rangeextentx = ceil(radius/londist);

[losbeginygp,losbeginxgp] = ind2sub(size(LOSterrain),pointnumber);

spany = losbeginygp-rangeextenty:losbeginygp+rangeextenty;
spanx = losbeginxgp-rangeextentx:losbeginxgp+rangeextentx;

spany = spany';
spanx = spanx';

cropspany = max([min(spany) 1]):min([max(spany) size(LOSterrain,1)]);
cropspanx = max([min(spanx) 1]):min([max(spanx) size(LOSterrain,2)]);

newlosbeginy = losbeginygp - min(cropspany) + 1;
newlosbeginx = losbeginxgp - min(cropspanx) + 1;

LOSterraincropped = LOSterrain(cropspany,cropspanx);

newpeakindex = sub2ind(size(LOSterraincropped),newlosbeginy,newlosbeginx);

croppedpointresults = perform_los_screen( elevation_m, latdist,londist,newpeakindex, radius, 0:0.8*(180/pi)*atan(londist/radius):360-(180/pi)*atan(londist/radius),LOSterraincropped,screen_m);

pointresults = zeros(size(LOSterrain));
pointresults(cropspany,cropspanx) = croppedpointresults;

visible = find(pointresults ~= 0);
[rows,cols] = ind2sub(size(pointresults),visible);

rowmin = min(rows);
rowmax = max(rows);
rowdiff = rowmax - rowmin;
colmin = min(cols);
colmax = max(cols);
coldiff = colmax - colmin;

pointsresultsformatted(1,:) = formatvismatrixresults_new(pointresults,rowmin,colmin,rowdiff,coldiff);
stringtofile = int2str(pointsresultsformatted(1,:));
stringtofile(ismember(stringtofile,' ')) = [];
% charstofile = char(stringtofile);
extent = cat(2,'[',int2str(rowmin),' ',int2str(rowdiff),' ',int2str(colmin),' ',int2str(coldiff),']');
extentpass = [rowmin rowdiff colmin coldiff];

test = char(bin2dec(reshape(stringtofile,7,[]).')).';


textfile = fopen(strcat(directory,'Extent',slashchar,num2str(pointnumber),'.txt'),'wt');
fprintf(textfile,extent);
fclose(textfile);
textfile = fopen(strcat(directory,'Visfiles',slashchar,num2str(pointnumber),'.txt'),'wt');
fprintf(textfile,'%c',test);
fclose(textfile);

textfile = fopen(strcat(directory,'Visfiles',slashchar,num2str(pointnumber),'.txt'),'r');
visarraytestread = fread(textfile,'*char')';
numerrors = size(visarraytestread,2) - size(test,2);
cnt = 1;
element = 1;
errors = [];
while cnt <= numerrors

    if visarraytestread(element) ~= test(element)
        errors(cnt) = element;
        visarraytestread(element) = [];
        cnt = cnt+1;
    end
    element = element + 1;  
end

errorfile = fopen(strcat(directory,'Errors',slashchar,num2str(pointnumber),'.txt'),'wt');
errortext = mat2str(errors);
fprintf(errorfile,errortext);
fclose(errorfile);
fclose(textfile);

% textfile = fopen(strcat(directory,'Visfiles',slashchar,num2str(pointnumber),'b','.txt'),'wt');
% fprintf(textfile,charstofile);
% fclose(textfile);
%textfile = fopen(strcat(directory,'Visfiles',slashchar,num2str(pointnumber),'.txt'),'r');
%binfile = fopen(strcat(directory,'Visfiles',slashchar,num2str(pointnumber),'.bin'),'wt');
%line = fread(textfile,'ubit1',6);
%line = fread(textfile,'ubit1',7);

%fwrite(binfile,line','ubit1',0);


%fclose(binfile);
%fclose(textfile);
     
%disp('NOT SAVING VISFILES IN calc_visibility.m !!!!!!')
%delete(strcat(directory,'Visfiles',slashchar,num2str(pointnumber),'.txt'));
end
          