function [visarray,extent,lostime] = read_visarray_screen_from_bin(directory,pointnumber,LOSterrain,f_type,screen_m)

if ispc
    slashchar = '\';
else
    slashchar = '/';
end

lostime = [0 0];

f_dir = strcat(num2str(screen_m),slashchar,'f',num2str(f_type),slashchar);
tic
binfile = fopen(strcat(directory,f_dir,'Visfiles',slashchar,num2str(pointnumber),'.txt'),'r');

if binfile == -1    
    [visarray,extent] = calc_visibility_screen(strcat(directory,f_dir),pointnumber,LOSterrain,screen_m);
    lostime(1) = toc;
else
    visarray = fread(binfile,'*char')';
    fclose(binfile);

    errorfile = fopen(strcat(directory,f_dir,'Errors',slashchar,num2str(pointnumber),'.txt'),'r');
    errors = eval(char(fread(errorfile,'char')'));
    fclose(errorfile);
    visarray(errors) = [];
   
    visarray = reshape(dec2bin(visarray,7)',1,numel(dec2bin(visarray,7)));
    visarray = visarray - '0';

    extentfile = fopen(strcat(directory,f_dir,'Extent',slashchar,...
        num2str(pointnumber),'.txt'),'r');
    extent = eval(char(fread(extentfile,'char')'));
    fclose(extentfile);
    
    
    lostime(2) = toc;
end

end
