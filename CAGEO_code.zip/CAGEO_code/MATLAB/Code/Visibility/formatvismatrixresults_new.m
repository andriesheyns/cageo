function [vismatrixformatted] = formatvismatrixresults_new(vismatrix,rowmin,colmin,rowdiff,coldiff)

vismatrixformatted = [];
for row = rowmin:rowmin+rowdiff
    vismatrixformatted = cat(2,vismatrixformatted,vismatrix(row,colmin:colmin+coldiff));
end
tempsize = size(vismatrixformatted,2);
if mod(tempsize,7)~= 0
    fillsize = 7-mod(tempsize,7);
    vismatrixformatted(1,tempsize+1:tempsize+fillsize) = 0;
end
end


