function [VisMatrix] = perform_los_screen( beginheightoffset, latdist,londist,losbeginpoint,losradius, angleset, LOSgrid,screen_m)

if beginheightoffset < 0
    VisMatrix = 0;
    
    disp('Be careful!  Negative beginoffset - youre doing LOS from under the ground!');
    
else
    
    EastA = zeros(size(LOSgrid,1),size(LOSgrid,2));
    NorthA = zeros(size(LOSgrid,1),size(LOSgrid,2));
    
    for row = 1:size(EastA,1)
        for col = 1:size(EastA,2)
            EastA(row,col) = (col-1)*londist;
            NorthA(row,col) = (row-1)*latdist;
        end
    end
    
    losbeginyM = NorthA(losbeginpoint);
    losbeginxM = EastA(losbeginpoint);
    
    gpspacinglatM = NorthA(2,1) - NorthA(1,1);
    gpspacinglonM = EastA(1,2) - EastA(1,1);
    
    Gr = 1;
    Gc = 1;
    
    VisMatrix = zeros(size(LOSgrid,1),size(LOSgrid,2));
    
    VisMatrix(losbeginpoint) = 1;
    
    [losbeginygp,losbeginxgp] = ind2sub(size(VisMatrix),losbeginpoint);
    
    beginheight = LOSgrid(losbeginpoint);
    begineast = EastA(losbeginpoint);
    beginnorth = NorthA(losbeginpoint);
    
    shiftangle = atan(gpspacinglatM/gpspacinglonM);
    
    %     prevpath = zeros(2,2*round(losradius/gpspacinglonM));
    
    for count = 1:size(angleset,2)
        
        losangledeg = angleset(1,count);
        
        if losangledeg < 0
            losangledeg = losangledeg + 360;
        end
        
        losanglerad = (losangledeg/180)*pi;
        cosltheta = cos(losanglerad);
        sinltheta = sin(losanglerad);
        tanltheta = tan(losanglerad);
        
        if (losanglerad <= shiftangle) || ((losanglerad >= pi - shiftangle)&&(losanglerad <= pi + shiftangle)) || (losanglerad >= 2*pi - shiftangle)
            
            if abs(cosltheta) <10e-017
                losdistinc = gpspacinglatM;
            else
                losdistinc = abs(gpspacinglonM/cosltheta);
            end
            
        else
            
            if sinltheta <10e-017
                losdistinc = gpspacinglonM;
            else
                losdistinc = abs(gpspacinglatM/sinltheta);
            end
            losdistinc = abs(gpspacinglatM/sinltheta);
            
        end
        
        losxinc = losdistinc*cosltheta;
        losyinc = losdistinc*sinltheta;
        
        lospointyvalM = losbeginyM + losyinc;
        lospointxvalM = losbeginxM + losxinc;
        
        lospointygp = losbeginygp + round((lospointyvalM - losbeginyM)/gpspacinglatM);
        lospointxgp = losbeginxgp + round((lospointxvalM - losbeginxM)/gpspacinglonM);
        
        if ((lospointxgp >= 1) && (lospointxgp <= size(EastA,2)))  && ((lospointygp >= 1) && (lospointygp <= size(NorthA,1)))
            
            pointheight = LOSgrid(lospointygp,lospointxgp);
            pointeast = (lospointxgp - Gc)*gpspacinglonM;
            pointnorth = (lospointygp - Gr)*gpspacinglatM;
            
            minelevationrad = getelevationangle(pointheight,pointeast,pointnorth,beginheight,beginheightoffset,begineast,beginnorth);
            
            %             lospath = [lospointygp;lospointxgp;minelevationrad];
            %             stepcount = 2;
            
            losdistdone = losdistinc;
            if ((lospointxgp >= 1) && (lospointxgp <= size(EastA,2))) ...
                    && ((lospointygp >= 1) && (lospointygp <= size(NorthA,1))) ...
                    && (losdistdone - losradius < 1*10e-3)
                
                VisMatrix(lospointygp,lospointxgp) = 1;
            end
            
            
            %%%%%%%%%%%%%%%%%%%%%%%%
            %first point done, now set up 2nd point for while loop
            
            lospointyvalM = losbeginyM + 2*losyinc;
            lospointxvalM = losbeginxM + 2*losxinc;
            
            lospointxgp = losbeginxgp + round((lospointxvalM - losbeginxM)/gpspacinglonM);
            lospointygp = losbeginygp + round((lospointyvalM - losbeginyM)/gpspacinglatM);
            
            losdistdone = 2*losdistinc;
            
            %             lospath(1:2,stepcount) = [lospointygp;lospointxgp];
            %
            %             while prevpath(1,stepcount) == lospath(1,stepcount) && prevpath(2,stepcount) == lospath(2,stepcount)
            %
            %                 lospointyvalM = losbeginyM + 2*losyinc;
            %                 lospointxvalM = losbeginxM + 2*losxinc;
            %
            %                 lospointxgp = losbeginxgp + round((lospointxvalM - losbeginxM)/gpspacinglonM);
            %                 lospointygp = losbeginygp + round((lospointyvalM - losbeginyM)/gpspacinglatM);
            %
            %                 stepcount = stepcount + 1;
            %
            %                 lospath(1:2,stepcount) = [lospointygp;lospointxgp];
            %
            %             end
            %             if stepcount >2
            %                 losdisteast =  abs(lospointxgp - losbeginxgp)*gpspacinglonM;
            %                 losdistnorth = abs(lospointygp - losbeginygp)*gpspacinglatM;
            %                 losdistdone = sqrt( losdisteast^2 + losdistnorth^2 );
            %
            %                 lospath = prevpath(:,1:stepcount-1);
            %                 lospath(1:2,stepcount) = [lospointygp;lospointxgp];
            %                 minelevationrad = prevpath(3,stepcount-1);
            %             end
            
            while ((lospointxgp >= 1) && (lospointxgp <= size(EastA,2))) ...
                    && ((lospointygp >= 1) && (lospointygp <= size(NorthA,1))) ...
                    && (losdistdone - losradius < 1*10e-3)
                
                %                 lospath(:,stepcount) = [lospointygp;lospointxgp;minelevationrad];
                %                 stepcount = stepcount + 1;
                
                pointheight = LOSgrid(lospointygp,lospointxgp);
                pointeast = (lospointxgp - Gc)*gpspacinglonM;
                pointnorth = (lospointygp - Gr)*gpspacinglatM;
                
                currentelevationrad = getelevationangle(pointheight,pointeast,pointnorth,beginheight,beginheightoffset,begineast,beginnorth);
                loselevationrad = getelevationangle(pointheight+screen_m,pointeast,pointnorth,beginheight,beginheightoffset,begineast,beginnorth);
                
                if loselevationrad >= minelevationrad
                    
                    if lospointygp <= size(LOSgrid,1)  && ...
                            lospointxgp <= size(LOSgrid,2)
                        VisMatrix(lospointygp,lospointxgp) = 1;
                    end
                    
                end
                
                if currentelevationrad >= minelevationrad
                    
                    minelevationrad = currentelevationrad;
                    
                end
                
                lospointyvalM = lospointyvalM + losyinc;
                lospointxvalM = lospointxvalM + losxinc;
                
                lospointxgp = losbeginxgp + round((lospointxvalM - losbeginxM)/gpspacinglonM);
                lospointygp = losbeginygp + round((lospointyvalM - losbeginyM)/gpspacinglatM);
                
                losdisteast =  abs(lospointxgp - losbeginxgp)*gpspacinglonM;
                losdistnorth = abs(lospointygp - losbeginygp)*gpspacinglatM;
                
                losdistdone = sqrt( losdisteast^2 + losdistnorth^2 );
                
            end
            %             prevpath = lospath;
            %             lospath = lospath-lospath;
            
        end
    end
    
    
    
end
