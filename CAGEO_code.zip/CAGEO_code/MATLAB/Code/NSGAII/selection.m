function pool = selection(prank,cd,tour_size,pool_size,population_size)

    tour=zeros(1,tour_size);
    pool=zeros(1,pool_size);
       
    for i=1:pool_size
        touched=zeros(1,population_size); % records whether or not a solution has already been chosen (touched) for a tournament
        t_cnt = 1;
        while sum(touched) < tour_size
            pnum = floor(rand*population_size) + 1;
            if touched(pnum) == 0
                touched(pnum) = 1;
                tour(t_cnt) = pnum;
                t_cnt = t_cnt+1;
            end
        end
        
        highest_rank = min(prank(tour));
        highest_cd = -1;
        
        for j=1:tour_size
            if prank(tour(j)) == highest_rank && cd(tour(j)) > highest_cd
                highest_cd = cd(tour(j));
                pool(i) = tour(j);
            end
        end
               
    end
    
end