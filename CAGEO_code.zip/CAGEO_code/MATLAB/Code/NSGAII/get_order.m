function [ n ] = get_order( a )

    n=zeros(1,length(a));
    for i=1:length(a)
        n(i)=i;
    end
    
    n=cat(1,a,n);
    
    n=sortrows(n',-1)';
    
    n=n(2,:);

end
