function varargout = MOFL(varargin)

gui_Singleton = 0;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @MOFL_OpeningFcn, ...
                   'gui_OutputFcn',  @MOFL_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end

% --- Executes just before MOFL is made visible.
function MOFL_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to MOFL (see VARARGIN)

% Choose default command line output for MOFL

handles.doplots = 0;
handles.half_NSGA_pop = 1;
set(handles.radio_nsga_half,'Value',1);

set(handles.objlistbox,'String',[]);

handles.psize = 1200;
handles.psize_list = [20 30 40 50 70 100 150 200 250 300 400 500 ...
    600 700 800 900 1000 1200 1500 1750 2000];
handles.NSGA_numruns = 1;
handles.NSGA_numruns_list = [1 2 5 10 15 20 30 40 50];
handles.NSGA_CR = 0.9;
handles.NSGA_CR_list = [0.5 0.6 0.7 0.8 0.9];
handles.NSGA_CRP = 3;
handles.NSGA_CRP_list = [1 2 3 0];
handles.NSGA_MR = 0.25;
handles.NSGA_MR_list = [0.01 0.02 0.03 0.04 0.06 0.07 0.08 0.09 ...
   0.10 0.125 0.15 0.175 0.20 0.225 0.25];

handles.threshold = 90;
handles.threshold_count = 10;
handles.threshold_HR = 90;
handles.threshold_count_HR = 10;
handles.threshold_half = 60;
handles.threshold_count_half = 5;

handles.GRIA_GI = 1;
handles.GRIA_GI_list = [1 2 3 4 5 6 7 8 9 10];
handles.GRIA_numruns = 1;
handles.GRIA_numruns_list = [1 2 5 10 15 20 30 40 50];

handles.HGA_numruns = 1;
handles.HGA_numruns_list = [1 2 5 10 15 20 30 40 50];
handles.HGA_CR = 0.5;
handles.HGA_CR_list = [0.5 0.6 0.7 0.8 0.9];
handles.HGA_CRP = 1;
handles.HGA_CRP_list = [1 2];
handles.HGA_GI = 1;
handles.HGA_GI_list = [1 2 3 4 5 6 7 8 9 10];

% handles.TABU_rounds_list = [0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20];
% handles.TABU_12_rounds = 0;
% handles.TABU_6_rounds = 0;
% handles.TABU_3_rounds = 0;
% handles.TABU_1_rounds = 0;

handles.output = hObject;

handles.queued_vars = [];
handles.queued_objectives_array = [];
handles.queued_objectives_count = [];
handles.queued_constraints_array = [];
handles.queued_constraints_count = [];

% handles.SZ1_n_f1_toplace = 3;
% handles.SZ2_n_f1_toplace = 3;
% handles.SZ1_n_f2_toplace = 3;
% handles.SZ2_n_f2_toplace = 3;
handles.distconstraint = 0;
handles.distconstraint_max = 0;
handles.force_linked_maxdist = 0;
handles.resolutions = [12 6 3 1];
handles.doresolutions = [0 0 1 1];
set(handles.radio_select3,'Value',1);
set(handles.radio_select1,'Value',1);
handles.quicktestmode = 0;

handles.constraints_string = {'Minimum value ' 'Maximum value '};
handles.constraints = [0 0 0 0 0 0 0 0 0 0 0 0 0 0 0];
handles.constraints_array = [];
handles.constraints_display_array = [];
handles.queued_tzp1_conarray = [];
handles.queued_tzp2_conarray = [];

handles.doobjectives = [0 0 0 0 0 0 0];
handles.doobjectives_string = {'MaxiMin ' 'MiniMax ' 'Dispersion ' 'Centring ' ...
                                'Max cover ' 'Min cover ' 'Max backup cover '};
handles.objectives = [0 0 0 0 0 0 0 0 0 0 0 0 0 0];
handles.objectives_array = [];
handles.objectives_display_array = [];
handles.queued_tzp1_objarray = [];
handles.queued_tzp2_objarray = [];

handles.queued_fac_array = [];
                            
handles.obj3_shared_nf = 2;
handles.obj3_shared_nf_list = [2 3 4 5 6 7 8 9 10];

handles.ES = 2;
handles.ES_list = [1 2 3 4 5 6 7 8 9 10 15];

set(handles.current_psize_display,'String','1200');
set(handles.current_gen_display,'String','0');
set(handles.current_tcount_display,'String','0');
set(handles.total_runtime_display,'String','0h0m');
set(handles.current_runtime_display,'String','0h0m');
set(handles.current_restime_display,'String','0h0m');
%set(handles.current_global_display,'String','0');
%set(handles.current_i_display,'String','0');

% Update handles structure
guidata(hObject, handles);

if handles.doplots
    
    axes(handles.candidate_locations);
    axis square;
    box on;
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    
    axes(handles.objplot);
    box on;
    grid on
    hold;
end
guidata(hObject, handles);

% --- Outputs from this function are returned to the command line.
function varargout = MOFL_OutputFcn(hObject, eventdata, handles) 
varargout{1} = handles.output;

function load_scenario_data_Callback(hObject, eventdata, handles)
uiopen;

handles.zone_data = zone_data;
handles.iz_data = iz_data;

handles.fac_array = zeros(size(zone_list,1),size(facility_list,1));
handles.facilities_display_array = [];
set(handles.facilities_add_list,'String',[]);

handles.tzpcon_array1_list = [];
handles.tzpcon_array2_list = [];

handles.tzpobj_array1 = zeros(size(zone_list,1),size(facility_list,1));
handles.tzpobj_array1_list = [];
set(handles.setpairlist1,'String',[]);
handles.tzpobj_array1_link = [];
handles.tzpobj_array1_link_cnt = 0;

handles.tzpobj_array2 = zeros(size(zone_list,1),size(facility_list,1));
handles.tzpobj_array2_list = [];
handles.tzpobj_array2_link = [];
handles.tzpobj_array2_link_cnt = 0;

handles.fac_array_link = [];

handles.sizeTerrain1 = size(Terrain1);

handles.BlankTerrain = zeros(size(Terrain1));

handles.LOSterrain = Terrain1;

handles.lat = lat_deg;
handles.latdist = latdist;
handles.londist = londist;

handles.binsdir = binsdir;

%[handles.visdata_15 handles.visdata_30] = load_visdata(binsdir,zone_data);

% handles.cover_array1 = cover_array1;
% handles.cover_array2 = cover_array2;

if handles.doplots
   
    axes(handles.candidate_locations);
    cla
    %surf(handles.Terrain1.*handles.Terrain1feasible,'EdgeColor','none');view(2);
    axis([-4 handles.sizeTerrain1(2)+5 -4 handles.sizeTerrain1(1)+5]);
    colormap(gray);
    axis square;
    box on;
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    hold;
end

%set(handles.visdata_folder_display,'String',binsdir);
handles.savedir = strcat(pwd,'/results/');
%set(handles.save_data_folder_display,'String',handles.savedir);
if ~(exist(strcat(pwd,'/results')) == 7)
    mkdir(strcat(pwd,'/results'));
end

handles.criteria_list = criteria_list;
handles.zone_list = zone_list;
set(handles.zonelistbox,'String',zone_list);
handles.facility_list = facility_list;
set(handles.facilitylistbox,'String',facility_list);
handles.iz_list = iz_list;
set(handles.izlistbox,'String',iz_list);

guidata(hObject, handles);

function start_runs_Callback(hObject, eventdata, handles)
new_vars = [handles.NSGA_numruns handles.NSGA_CR handles.NSGA_MR handles.threshold handles.threshold_count...
    handles.threshold_HR handles.threshold_count_HR handles.GRIA_GI handles.GRIA_numruns ...
    0 0 0 0 ...
    handles.distconstraint handles.distconstraint_max ...
    handles.doresolutions handles.quicktestmode handles.obj3_shared_nf...
    handles.ES 1 0 handles.NSGA_CRP...
    0 0 0 0 0 handles.psize handles.threshold_half...
    handles.threshold_count_half get(handles.radio_nsga_half,'Value')]';

handles.queued_tzp1_objarray = cat(3,handles.queued_tzp1_objarray,handles.tzpobj_array1_list);
handles.queued_tzp2_objarray = [];
handles.queued_tzp1_conarray = cat(3,handles.queued_tzp1_conarray,handles.tzpcon_array1_list);
handles.queued_tzp2_conarray = [];

handles.queued_fac_array = cat(3,handles.queued_fac_array,handles.fac_array);

handles.queued_vars = cat(2,handles.queued_vars,new_vars);
handles.queued_objectives_array = cat(1,handles.queued_objectives_array,handles.objectives_array);
handles.queued_objectives_count = cat(2,handles.queued_objectives_count,size(handles.objectives_array,1));
handles.queued_constraints_array = cat(1,handles.queued_constraints_array,handles.constraints_array);
handles.queued_constraints_count = cat(2,handles.queued_constraints_count,size(handles.constraints_array,1));

for num_runs = 1:size(handles.queued_vars,2)
    if num_runs == 1
        start_num = 1;
        start_num_con = 1;
    else
        start_num = sum(handles.queued_objectives_count(1,1:num_runs-1)) + 1;
        start_num_con = sum(handles.queued_constraints_count(1,1:num_runs-1)) + 1;
    end
    end_num = sum(handles.queued_objectives_count(1,1:num_runs));
    end_num_con = sum(handles.queued_constraints_count(1,1:num_runs));
    
    handles.objectives_array = handles.queued_objectives_array(start_num:end_num,:);   
    handles.objectives_tzp1_array = handles.queued_tzp1_objarray(:,:,start_num:end_num);   
    %handles.objectives_tzp2_array = [];%handles.queued_tzp2_objarray(:,:,start_num:end_num);   
    handles.f_array = handles.queued_fac_array(:,:,num_runs);   
    
    handles.constraints_array = handles.queued_constraints_array(start_num_con:end_num_con,:);   
    handles.constraints_tzp1_array = handles.queued_tzp1_conarray(:,:,start_num_con:end_num_con);   
    %handles.constraints_tzp2_array = [];%handles.queued_tzp2_conarray(:,:,start_num_con:end_num_con);   
    
    handles.NSGA_numruns = handles.queued_vars(1,num_runs);
    handles.NSGA_CR = handles.queued_vars(2,num_runs);
    handles.NSGA_MR = handles.queued_vars(3,num_runs);
    handles.threshold = handles.queued_vars(4,num_runs);
    handles.threshold_count = handles.queued_vars(5,num_runs);
    handles.threshold_HR = handles.queued_vars(6,num_runs);
    handles.threshold_count_HR = handles.queued_vars(7,num_runs);
    %handles.GRIA_GI = handles.queued_vars(8,num_runs);
    %handles.GRIA_numruns = handles.queued_vars(9,num_runs);
    handles.SZ1_n_f1_toplace = [];
    handles.SZ2_n_f1_toplace = [];
    handles.SZ1_n_f2_toplace = [];
    handles.SZ2_n_f2_toplace =[];    
    handles.distconstraint = handles.queued_vars(14,num_runs);
    handles.distconstraint_max = handles.queued_vars(15,num_runs);
    handles.doresolutions = handles.queued_vars([16:19],num_runs)';
    handles.quicktestmode = handles.queued_vars(20,num_runs);
    handles.obj3_shared_nf = handles.queued_vars(21,num_runs);
    handles.ES = handles.queued_vars(22,num_runs);
    handles.NSGA_CRP = handles.queued_vars(25,num_runs);
    %handles.HGA_numruns = handles.queued_vars(26,num_runs);
    %handles.HGA_CR = handles.queued_vars(27,num_runs);
    %handles.HGA_CRP = handles.queued_vars(28,num_runs);
    %handles.HGA_GI = handles.queued_vars(29,num_runs);
    handles.psize = handles.queued_vars(31,num_runs);
    handles.threshold_half = handles.queued_vars(32,num_runs);
    handles.threshold_count_half = handles.queued_vars(33,num_runs);
    handles.half_NSGA_pop = handles.queued_vars(34,num_runs);
    handles.n_obj = end_num-start_num+1;
    if handles.doplots
        axes(handles.candidate_locations);
        cla;
        axes(handles.objplot);
        cla;
    end    
    set(handles.total_runtime_display,'String','0h0m');
    set(handles.current_runtime_display,'String','0h0m');
    set(handles.current_restime_display,'String','0h0m');
    set(handles.current_psize_display,'String','0');
    set(handles.current_gen_display,'String','0');
    set(handles.current_tcount_display,'String','0');
    set(handles.status_display,'String','BUSY');
    set(handles.status_display,'BackgroundColor','red');
%    set(handles.STOP,'String','STOP');
%    set(handles.STOP,'BackgroundColor','red');
%    set(handles.current_global_display,'String','0');
%    set(handles.current_i_display,'String','0');
        
    if handles.queued_vars(23,num_runs) == 1
        set(handles.current_algorithm_display,'String','NSGA-II');
        handles.interrupt = execute_runs(handles,1);
        if handles.interrupt
            set(handles.status_display,'String','STOPPED');
            set(handles.status_display,'BackgroundColor','red');
        else
            set(handles.status_display,'String','DONE');
            set(handles.status_display,'BackgroundColor','yellow');
        end
%     elseif handles.queued_vars(24,num_runs) == 1
%         set(handles.current_algorithm_display,'String','AMOEBA');
%         handles.interrupt = execute_runs(handles,2);
%         if handles.interrupt
%             set(handles.status_display,'String','STOPPED');
%             set(handles.status_display,'BackgroundColor','red');
%         else
%             set(handles.status_display,'String','DONE');
%             set(handles.status_display,'BackgroundColor','yellow');
%         end
%     elseif handles.queued_vars(30,num_runs) == 1
%         set(handles.current_algorithm_display,'String','HGA');
%         handles.interrupt = execute_runs(handles,3);
%         if handles.interrupt
%             set(handles.status_display,'String','STOPPED');
%             set(handles.status_display,'BackgroundColor','red');
%         else
%             set(handles.status_display,'String','DONE');
%             set(handles.status_display,'BackgroundColor','yellow');
%         end
     end
end

function queue_runs_Callback(hObject, eventdata, handles)
new_vars = [handles.NSGA_numruns handles.NSGA_CR handles.NSGA_MR handles.threshold handles.threshold_count...
    handles.threshold_HR handles.threshold_count_HR handles.GRIA_GI handles.GRIA_numruns ...
    0 0 0 0 ...
    handles.distconstraint handles.distconstraint_max ...
    handles.doresolutions handles.quicktestmode handles.obj3_shared_nf...
    handles.ES 1 0 handles.NSGA_CRP...
    0 0 0 0 0 handles.psize handles.threshold_half...
    handles.threshold_count_half get(handles.radio_nsga_half,'Value')]';

handles.queued_tzp1_objarray = cat(3,handles.queued_tzp1_objarray,handles.tzpobj_array1_list);
handles.queued_tzp2_objarray = [];
handles.queued_tzp1_conarray = cat(3,handles.queued_tzp1_conarray,handles.tzpcon_array1_list);
handles.queued_tzp2_conarray = [];

handles.queued_fac_array = cat(3,handles.queued_fac_array,handles.fac_array);

handles.queued_vars = cat(2,handles.queued_vars,new_vars);
handles.queued_objectives_array = cat(1,handles.queued_objectives_array,handles.objectives_array);
handles.queued_objectives_count = cat(2,handles.queued_objectives_count,size(handles.objectives_array,1));
handles.queued_constraints_array = cat(1,handles.queued_constraints_array,handles.constraints_array);
handles.queued_constraints_count = cat(2,handles.queued_constraints_count,size(handles.constraints_array,1));

guidata(hObject, handles);

function clear_queue_Callback(hObject, eventdata, handles)
handles.queued_vars = [];
handles.queued_objectives_array = [];
handles.queued_constraints_array = [];
handles.queued_objectives_count = [];
handles.queued_constraints_count = [];
handles.queued_tzp1_objarray = []; %= zeros(size(handles.fac_array));
handles.queued_tzp2_objarray = []; %zeros(size(handles.fac_array));
handles.queued_tzp1_conarray = []; %= zeros(size(handles.fac_array));
handles.queued_tzp2_conarray = []; %zeros(size(handles.fac_array));
handles.queued_fac_array = [];
guidata(hObject, handles);

function STOP_Callback(hObject, eventdata, handles)
if strcmp(get(handles.STOP,'String'),'STOP');
    set(handles.STOP,'String','STOPPED');
    set(handles.STOP,'BackgroundColor','white');
else
    set(handles.STOP,'String','STOP');
    set(handles.STOP,'BackgroundColor','red');
end
guidata(hObject, handles);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%  ALGORITHM PARAMETERS
%%%  ALGORITHM PARAMETERS
%%%  ALGORITHM PARAMETERS
%%%  ALGORITHM PARAMETERS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function select_nsga_Callback(hObject, eventdata, handles)
guidata(hObject, handles);

%%%%%%%%%%%%%%%NSGA
%%%%%%%%%%%%%%%%
function NSGA_numruns_select_Callback(hObject, eventdata, handles)
if get(handles.NSGA_numruns_select,'Value') == 0
    handles.NSGA_numruns = [];
else
    handles.NSGA_numruns = handles.NSGA_numruns_list(get(handles.NSGA_numruns_select,'Value'));
end
guidata(hObject, handles);

function NSGA_numruns_select_CreateFcn(hObject, eventdata, handles)

function NSGA_mutation_rate_Callback(hObject, eventdata, handles)
if get(handles.NSGA_mutation_rate,'Value') == 0
    handles.NSGA_MR = [];
else
    handles.NSGA_MR = handles.NSGA_MR_list(get(handles.NSGA_mutation_rate,'Value'));
end
guidata(hObject, handles);

function NSGA_mutation_rate_CreateFcn(hObject, eventdata, handles)

function NSGA_crossover_rate_Callback(hObject, eventdata, handles)
if get(handles.NSGA_crossover_rate,'Value') == 0
    handles.NSGA_CR = [];
else
    handles.NSGA_CR = handles.NSGA_CR_list(get(handles.NSGA_crossover_rate,'Value'));
end
guidata(hObject, handles);

function NSGA_crossover_rate_CreateFcn(hObject, eventdata, handles)

function NSGA_crossover_points_Callback(hObject, eventdata, handles)
handles.NSGA_CRP = handles.NSGA_CRP_list(get(handles.NSGA_crossover_points,'Value'));
guidata(hObject, handles);

function NSGA_crossover_points_CreateFcn(hObject, eventdata, handles);

%%%%%%%%%%%%%%%%%GRIA
%%%%%%%%%%%%%%%%%%%%
function GRIA_numruns_select_Callback(hObject, eventdata, handles)
if get(handles.GRIA_numruns_select,'Value') == 0
    handles.GRIA_numruns = [];
else
    handles.GRIA_numruns = handles.GRIA_numruns_list(get(handles.GRIA_numruns_select,'Value'));
end
guidata(hObject, handles);

function GRIA_numruns_select_CreateFcn(hObject, eventdata, handles)

function GRIA_global_iterations_Callback(hObject, eventdata, handles)
if get(handles.GRIA_global_iterations,'Value') == 0
    handles.GRIA_GI = [];
else
    handles.GRIA_GI = handles.GRIA_GI_list(get(handles.GRIA_global_iterations,'Value'));
end
guidata(hObject, handles);

function GRIA_global_iterations_CreateFcn(hObject, eventdata, handles)

%%%%%%%%%%%%%%%%%HGA
%%%%%%%%%%%%%%%%%%%%
function HGA_global_iterations_Callback(hObject, eventdata, handles)
if get(handles.HGA_global_iterations,'Value') == 0
    handles.HGA_GI = [];
else
    handles.HGA_GI = handles.HGA_GI_list(get(handles.HGA_global_iterations,'Value'));
end
guidata(hObject, handles);

function HGA_global_iterations_CreateFcn(hObject, eventdata, handles)

function HGA_numruns_select_Callback(hObject, eventdata, handles)
if get(handles.HGA_numruns_select,'Value') == 0
    handles.HGA_numruns = [];
else
    handles.HGA_numruns = handles.HGA_numruns_list(get(handles.HGA_numruns_select,'Value'));
end
guidata(hObject, handles);

function HGA_numruns_select_CreateFcn(hObject, eventdata, handles)

function HGA_crossover_rate_Callback(hObject, eventdata, handles)
if get(handles.HGA_crossover_rate,'Value') == 0
    handles.HGA_CR = [];
else
    handles.HGA_CR = handles.HGA_CR_list(get(handles.HGA_crossover_rate,'Value'));
end
guidata(hObject, handles);

function HGA_crossover_rate_CreateFcn(hObject, eventdata, handles)

function HGA_crossover_points_Callback(hObject, eventdata, handles)
handles.HGA_CRP = handles.HGA_CRP_list(get(handles.HGA_crossover_points,'Value'));
guidata(hObject, handles);

function HGA_crossover_points_CreateFcn(hObject, eventdata, handles)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%  GENERAL PARAMETERS
%%%  GENERAL PARAMETERS
%%%  GENERAL PARAMETERS
%%%  GENERAL PARAMETERS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function distconstraint_edit_Callback(hObject, eventdata, handles)
handles.distconstraint = str2double(get(handles.distconstraint_edit,'String'));
guidata(hObject, handles);

function distconstraint_edit_CreateFcn(hObject, eventdata, handles)

function distconstraint_max_edit_Callback(hObject, eventdata, handles)
handles.distconstraint_max = str2double(get(handles.distconstraint_max_edit,'String'));
guidata(hObject, handles);

function distconstraint_max_edit_CreateFcn(hObject, eventdata, handles)

function check_maxdist_linked_Callback(hObject, eventdata, handles)
handles.force_linked_maxdist = get(handles.check_maxdist_linked,'Value');
guidata(hObject, handles);

function radio_select12_Callback(hObject, eventdata, handles)
handles.doresolutions(1) = get(hObject,'Value');
guidata(hObject, handles);

function radio_select6_Callback(hObject, eventdata, handles)
handles.doresolutions(2) = get(hObject,'Value');
guidata(hObject, handles);

% function radio_select3_Callback(hObject, eventdata, handles)
% handles.doresolutions(3) = get(hObject,'Value');
% guidata(hObject, handles);
% 
% function radio_select1_Callback(hObject, eventdata, handles)
% handles.doresolutions(4) = get(hObject,'Value');
% guidata(hObject, handles);

function expand_size_Callback(hObject, eventdata, handles)
if get(handles.expand_size,'Value') == 0
    handles.ES = [];
else
    handles.ES = handles.ES_list(get(handles.expand_size,'Value'));
end
guidata(hObject, handles);

function expand_size_CreateFcn(hObject, eventdata, handles)

function threshold_perc_edit_Callback(hObject, eventdata, handles)
handles.threshold = str2double(get(handles.threshold_perc_edit,'String'));
guidata(hObject, handles);

function threshold_perc_edit_CreateFcn(hObject, eventdata, handles)

function threshold_count_edit_Callback(hObject, eventdata, handles)
handles.threshold_count = str2double(get(handles.threshold_count_edit,'String'));
guidata(hObject, handles);

function threshold_count_edit_CreateFcn(hObject, eventdata, handles)

function threshold_perc_edit_HR_Callback(hObject, eventdata, handles)
handles.threshold_HR = str2double(get(handles.threshold_perc_edit_HR,'String'));
guidata(hObject, handles);

function threshold_perc_edit_HR_CreateFcn(hObject, eventdata, handles)

function threshold_count_edit_HR_Callback(hObject, eventdata, handles)
handles.threshold_count_HR = str2double(get(handles.threshold_count_edit_HR,'String'));
guidata(hObject, handles);

function threshold_count_edit_HR_CreateFcn(hObject, eventdata, handles)

function popsize_Callback(hObject, eventdata, handles)
handles.psize = str2double(get(handles.popsize,'String'));
guidata(hObject, handles);

function popsize_CreateFcn(hObject, eventdata, handles)

function popsizelist_Callback(hObject, eventdata, handles)
if get(handles.popsizelist,'Value') == 0
    handles.psize = [];
else
    handles.psize = handles.psize_list(get(handles.popsizelist,'Value'));
end
set(handles.popsize,'String',num2str(handles.psize));
guidata(hObject, handles);

function popsizelist_CreateFcn(hObject, eventdata, handles)

function threshold_count_edit_half_Callback(hObject, eventdata, handles)
handles.threshold_count_half = str2double(get(handles.threshold_count_edit_half,'String'));
guidata(hObject, handles);

function threshold_count_edit_half_CreateFcn(hObject, eventdata, handles)

function threshold_perc_edit_half_Callback(hObject, eventdata, handles)
handles.threshold_half = str2double(get(handles.threshold_perc_edit_half,'String'));
guidata(hObject, handles);

function threshold_perc_edit_half_CreateFcn(hObject, eventdata, handles)

function radio_nsga_half_Callback(hObject, eventdata, handles)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%  DISPLAY STUFF
%%%  DISPLAY STUFF
%%%  DISPLAY STUFF
%%%  DISPLAY STUFF
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function status_display_CreateFcn(hObject, eventdata, handles)

function total_number_runs_display_CreateFcn(hObject, eventdata, handles)

function current_run_number_display_CreateFcn(hObject, eventdata, handles)

function current_resolution_display_CreateFcn(hObject, eventdata, handles)

function current_psize_display_CreateFcn(hObject, eventdata, handles)

function current_gen_display_CreateFcn(hObject, eventdata, handles)

function current_tcount_display_CreateFcn(hObject, eventdata, handles)

function total_runtime_display_CreateFcn(hObject, eventdata, handles)

function current_runtime_display_CreateFcn(hObject, eventdata, handles)

function current_restime_display_CreateFcn(hObject, eventdata, handles)

function current_global_display_CreateFcn(hObject, eventdata, handles)

function current_i_display_CreateFcn(hObject, eventdata, handles)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%  OBJECTIVES
%%%  OBJECTIVES
%%%  OBJECTIVES
%%%  OBJECTIVES
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% function radio_obj5_Callback(hObject, eventdata, handles)
% handles.doobjectives = [0 0 0 0 0 0 0];
% handles.doobjectives(5) = 1;
% guidata(hObject, handles);

function obj3_shared_nf_select_CreateFcn(hObject, eventdata, handles)

function obj3_shared_nf_select_Callback(hObject, eventdata, handles)
if get(handles.obj3_shared_nf_select,'Value') == 0
    handles.obj3_shared_nf = [];
else
    handles.obj3_shared_nf = handles.obj3_shared_nf_list(get(handles.obj3_shared_nf_select,'Value'));
end
guidata(hObject, handles);

function objlistbox_Callback(hObject, eventdata, handles)

function objlistbox_CreateFcn(hObject, eventdata, handles)

function addobj_Callback(hObject, eventdata, handles)
handles.objectives = [0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0];
obj_num = find(handles.doobjectives == 1);
handles.objectives(1) = obj_num;
obj_string = [];
obj_string = strcat(obj_string,handles.doobjectives_string(obj_num));
obj_string = strcat(obj_string,'\\',{' '});

if any(handles.objectives(1) == [1 2])
    handles.objectives(17) = get(handles.criterialistbox,'Value');
    obj_string = strcat(obj_string,handles.criteria_list{handles.objectives(17)})
    obj_string = strcat(obj_string,{' '});
end

if any(handles.objectives(1) == [3 4])
    
    obj_string = strcat(obj_string,{' '},'from',{' '});
      
end

if any(handles.objectives(1) == [5 6 7])
    handles.objectives(8) = get(handles.izlistbox,'Value');
    if handles.objectives(1) == 7
        handles.objectives(10) = ...
            handles.obj3_shared_nf_list(get(handles.obj3_shared_nf_select,'Value'));
    end
end

handles.tzpobj_array1_list = cat(3,handles.tzpobj_array1_list,handles.tzpobj_array1);
handles.tzpobj_array2_list = cat(3,handles.tzpobj_array2_list,handles.tzpobj_array2);

handles.objectives_array = cat(1,handles.objectives_array,handles.objectives);
handles.objectives_display_array = cat(1,handles.objectives_display_array,obj_string);
set(handles.objlistbox,'String',handles.objectives_display_array);
guidata(hObject, handles);

%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%

function constraintlistbox_Callback(hObject, eventdata, handles)

function constraintlistbox_CreateFcn(hObject, eventdata, handles)

function radio_constraint1_Callback(hObject, eventdata, handles)
set(handles.radio_constraint2,'Value',0);
guidata(hObject, handles);

function radio_constraint2_Callback(hObject, eventdata, handles)
set(handles.radio_constraint1,'Value',0);
guidata(hObject, handles);

function addconstraint_Callback(hObject, eventdata, handles)
handles.constraints = [0 0 0 0 0 0 0 0 0 0 0 0 0 0 0];
if get(handles.radio_constraint1,'Value') == 1
    handles.constraints(1) = 1;
elseif get(handles.radio_constraint2,'Value') == 1
    handles.constraints(1) = 2;
end
handles.constraints(2) = get(handles.constraint_isdistance,'Value');
if get(handles.constraint_iscost,'Value') == 1
    handles.constraints(2) = 2;
end

constraint_string = [];
constraint_string = strcat(constraint_string,handles.constraints_string(handles.constraints(1)));
constraint_string = strcat(constraint_string,'\\\');

if handles.constraints(2) == 0
    handles.constraints(3) = get(handles.criterialistbox,'Value');
    constraint_string = strcat(constraint_string,handles.criteria_list{handles.constraints(3)})
    constraint_string = strcat(constraint_string,{' '});
end

if handles.constraints(1) == 2 && get(handles.check_maxdist_linked,'Value') == 1

        handles.constraints(8) = str2double(get(handles.distconstraint_max_edit,'String'));
        constraint_string = strcat(constraint_string,'\\\==>');
        constraint_string = strcat(constraint_string, get(handles.distconstraint_max_edit,'String'));

    handles.constraints(9) = 1;
    constraint_string = strcat(constraint_string,'\\\force linked');
else
    
    constraint_string = strcat(constraint_string,{' '},'from',{' '});      
     
    if handles.constraints(1) == 1
        handles.constraints(8) = str2double(get(handles.distconstraint_edit,'String'));
        constraint_string = strcat(constraint_string,'\\\==>');
        constraint_string = strcat(constraint_string, get(handles.distconstraint_edit,'String'));
    elseif handles.constraints(1) == 2
        handles.constraints(8) = str2double(get(handles.distconstraint_max_edit,'String'));
        constraint_string = strcat(constraint_string,'\\\==>');
        constraint_string = strcat(constraint_string, get(handles.distconstraint_max_edit,'String'));
    end
    
end

handles.tzpcon_array1_list = cat(3,handles.tzpcon_array1_list,handles.tzpobj_array1);
handles.tzpcon_array2_list = cat(3,handles.tzpcon_array2_list,handles.tzpobj_array2);

handles.constraints_array = cat(1,handles.constraints_array,handles.constraints);
handles.constraints_display_array = cat(1,handles.constraints_display_array,constraint_string);
set(handles.constraintlistbox,'String',handles.constraints_display_array);
guidata(hObject, handles);

function clear_all_constraints_Callback(hObject, eventdata, handles)
handles.tzpcon_array1_list = [];
handles.tzpcon_array2_list = [];
handles.constraints_display_array = [];
set(handles.constraintlistbox,'String',handles.constraints_display_array);
handles.constraints_array = [];
guidata(hObject, handles);

function remove_selected_constraint_Callback(hObject, eventdata, handles)
remove_constraint_num = get(handles.constraintlistbox,'Value');
handles.constraints_display_array(remove_constraint_num,:) = [];
set(handles.constraintlistbox,'Value',1,'String',handles.constraints_display_array);
handles.constraints_array(remove_constraint_num,:) = [];
handles.tzpcon_array1_list(:,:,remove_constraint_num) = [];
handles.tzpcon_array2_list(:,:,remove_constraint_num) = [];
guidata(hObject, handles);

function criterialistbox_Callback(hObject, eventdata, handles)

function criterialistbox_CreateFcn(hObject, eventdata, handles)

function zonelistbox_Callback(hObject, eventdata, handles)

function zonelistbox_CreateFcn(hObject, eventdata, handles)

function facilitylistbox_Callback(hObject, eventdata, handles)

function facilitylistbox_CreateFcn(hObject, eventdata, handles)

function addfacilities_Callback(hObject, eventdata, handles)

handles.fac_array(get(handles.zonelistbox,'Value'),get(handles.facilitylistbox,'Value'))...
    = str2double(get(handles.f_num_add_edit,'String'));

add_string = [];
add_string = strcat(add_string,handles.zone_list{get(handles.zonelistbox,'Value')},'->',{' '});
add_string = strcat(add_string,get(handles.f_num_add_edit,'String'),' x ');
add_string = strcat(add_string,{' '},handles.facility_list{get(handles.facilitylistbox,'Value')});

handles.facilities_display_array{(get(handles.zonelistbox,'Value')-1)*size(handles.fac_array,2)...
    + get(handles.facilitylistbox,'Value'),1} = char(add_string);

display_copy = handles.facilities_display_array;
temp_list = (1:size(handles.fac_array,1)*size(handles.fac_array,2))';
empty_list = zeros(size(temp_list));
empty_list(1:size(cellfun(@(display_copy) ~isempty(display_copy),display_copy),1)) = cellfun(@(display_copy) ~isempty(display_copy),display_copy);
temp_list = temp_list.*empty_list;
temp_list(find(temp_list ==0)) = [];
display_copy(cellfun(@(display_copy) isempty(display_copy),display_copy))=[];
handles.fac_array_link = temp_list;
%(1:size(zone_list,1)*size(facility_list,1))';

set(handles.facilities_add_list,'String',display_copy);

guidata(hObject, handles);

temp = handles.tzpobj_array1';

if temp(handles.fac_array_link(get(handles.facilities_add_list,'Value'))) ~= 1
    
    handles.tzpobj_array1 = handles.tzpobj_array1';
    handles.tzpobj_array1(handles.fac_array_link(get(handles.facilities_add_list,'Value'))) = 1;
    handles.tzpobj_array1_link(handles.tzpobj_array1_link_cnt+1) = handles.fac_array_link(get(handles.facilities_add_list,'Value'));
    handles.tzpobj_array1_link_cnt = handles.tzpobj_array1_link_cnt + 1;
    handles.tzpobj_array1 = handles.tzpobj_array1';
    
    list_entry = cellstr(get(handles.facilities_add_list,'String'));
    index_selected = get(handles.facilities_add_list,'Value');  %changed line
    choice_facilities_add_list = list_entry(index_selected);
    update_setpairlist1 = cellstr(get(handles.setpairlist1, 'String'));
    update_setpairlist1(cellfun(@(update_setpairlist1) isempty(update_setpairlist1),update_setpairlist1))=[];
    newmenu = [update_setpairlist1; choice_facilities_add_list];
    set(handles.setpairlist1,'String', newmenu);
    
end

set(handles.radio_obj5,'Value',1);
handles.doobjectives = [0 0 0 0 0 0 0];
handles.doobjectives(5) = 1;

guidata(hObject, handles);



function facilities_add_list_Callback(hObject, eventdata, handles)

function facilities_add_list_CreateFcn(hObject, eventdata, handles)

function clear_all_facs_Callback(hObject, eventdata, handles)
handles.fac_array = zeros(size(handles.fac_array));
handles.facilities_display_array = [];
set(handles.facilities_add_list,'String',[]);

set(handles.facilities_add_list,'Value',1);

handles.fac_array_link = [];

function remove_selected_facs_Callback(hObject, eventdata, handles)

remove_fac_num = get(handles.facilities_add_list,'Value');

handles.fac_array = handles.fac_array';
handles.fac_array(handles.fac_array_link(remove_fac_num)) = 0;
handles.fac_array = handles.fac_array';
handles.facilities_display_array{handles.fac_array_link(remove_fac_num),1} = [];
handles.fac_array_link(remove_fac_num) = [];
    
display_copy = handles.facilities_display_array;
temp_list = (1:size(handles.fac_array,1)*size(handles.fac_array,2))';
empty_list = zeros(size(temp_list));
empty_list(1:size(cellfun(@(display_copy) ~isempty(display_copy),display_copy),1)) = cellfun(@(display_copy) ~isempty(display_copy),display_copy);
temp_list = temp_list.*empty_list;
temp_list(find(temp_list ==0)) = [];
display_copy(cellfun(@(display_copy) isempty(display_copy),display_copy))=[];
handles.fac_array_link = temp_list;
%(1:size(zone_list,1)*size(facility_list,1))';

set(handles.facilities_add_list,'String',display_copy);

if remove_fac_num > 1
    set(handles.facilities_add_list,'Value',remove_fac_num - 1);
else
    set(handles.facilities_add_list,'Value',1);
end

guidata(hObject, handles);

function f_num_add_edit_Callback(hObject, eventdata, handles)

function f_num_add_edit_CreateFcn(hObject, eventdata, handles)

function izlistbox_Callback(hObject, eventdata, handles)

function izlistbox_CreateFcn(hObject, eventdata, handles)

function setpairlist1_Callback(hObject, eventdata, handles)

function setpairlist1_CreateFcn(hObject, eventdata, handles)

function setpairlist2_Callback(hObject, eventdata, handles)

function setpairlist2_CreateFcn(hObject, eventdata, handles)

function addsetpair1_Callback(hObject, eventdata, handles)

% temp = handles.tzpobj_array1';
% 
% if temp(handles.fac_array_link(get(handles.facilities_add_list,'Value'))) ~= 1
%     
%     handles.tzpobj_array1 = handles.tzpobj_array1';
%     handles.tzpobj_array1(handles.fac_array_link(get(handles.facilities_add_list,'Value'))) = 1;
%     handles.tzpobj_array1_link(handles.tzpobj_array1_link_cnt+1) = handles.fac_array_link(get(handles.facilities_add_list,'Value'));
%     handles.tzpobj_array1_link_cnt = handles.tzpobj_array1_link_cnt + 1;
%     handles.tzpobj_array1 = handles.tzpobj_array1';
%     
%     list_entry = cellstr(get(handles.facilities_add_list,'String'));
%     index_selected = get(handles.facilities_add_list,'Value');  %changed line
%     choice_facilities_add_list = list_entry(index_selected);
%     update_setpairlist1 = cellstr(get(handles.setpairlist1, 'String'));
%     update_setpairlist1(cellfun(@(update_setpairlist1) isempty(update_setpairlist1),update_setpairlist1))=[];
%     newmenu = [update_setpairlist1; choice_facilities_add_list];
%     set(handles.setpairlist1,'String', newmenu);
%     
% end
% guidata(hObject, handles);

% --- Executes on button press in random_start.
function random_start_Callback(hObject, eventdata, handles)
% hObject    handle to random_start (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of random_start


% --- Executes on button press in local_mutation_select.
function local_mutation_select_Callback(hObject, eventdata, handles)
% hObject    handle to local_mutation_select (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of local_mutation_select
