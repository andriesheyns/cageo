function [Obj_matrix,lostime] = evaluate_chromosome_population...
    (P,n_obj,pointdata,...
    lostime,h,prev_pop_obj,current_res,visresults_mem)

if ispc
    slashchar = '\';
else
    slashchar = '/';
end

population_size = size(P,2);
Obj_matrix = zeros(n_obj,population_size);

filereads = false;

n_f_toplace = size(P,1);

for i = 1:population_size
    
    searchp = P(:,i)';
    notfound = 1;
    
    if notfound
        
        before = 0;
        refgrid1list = [];
        for z_num = 1:size(h.f_array,1)
            for f_num = 1:size(h.f_array,2)
                refgrid1points{z_num,f_num} = ...
                    pointdata{z_num,1}.pointslist(searchp(before+1:before + h.f_array(z_num,f_num)));
                refgrid1list = unique(cat(2,refgrid1list,refgrid1points{z_num,f_num}));
                before = before + h.f_array(z_num,f_num);
            end
        end
        
        before = 0;
        for z_num = 1:size(h.f_array,1)
            for f_num = 1:size(h.f_array,2)
                localzonepoints{z_num,f_num} = ...
                    pointdata{z_num,1}.localindex(searchp(before+1:before + h.f_array(z_num,f_num)));
                before = before + h.f_array(z_num,f_num);
            end
        end
        
        if any(h.objectives_array(:,1) == 5) ||...
                any(h.objectives_array(:,1) == 6) ||...
                any(h.objectives_array(:,1) == 7)
            
            filereads = true;
            
        end
        
        if isempty(visresults_mem) && filereads == 1
            
            [visresults, add_lostime] = ...
                ...
                read_f_array([],n_obj,...
                refgrid1points,h);
            
            lostime = lostime + add_lostime;
            
            
        end
        
        
        %%%%%%%%%%%%%%%%%%
        
        obj_cnt = 1;
        for current_obj = 1:n_obj
            notdone = 1;
            
            if h.objectives_array(current_obj,1) == 5
                iz_num = h.objectives_array(current_obj,8);
                
                vissum = zeros(1,size(h.iz_data{iz_num,1}.interest1,2));
                
                for z_num = 1:size(h.f_array,1)
                    for f_num = 1:size(h.f_array,2)
                        if h.objectives_tzp1_array(z_num,f_num,current_obj) > 0
                            vissum = vissum + visresults{iz_num,1}.zone{z_num,1}.facility{f_num};
                        end
                    end
                end
                sharedvis = find(vissum >=1);
                sharedvis = size(sharedvis,2);
                division = size(h.iz_data{iz_num,1}.interest1,2)/100;
                
                Obj_matrix(obj_cnt,i) = sharedvis/division;
                obj_cnt = obj_cnt + 1;
                notdone = 0;
            end
            
            if h.objectives_array(current_obj,1) == 6
                iz_num = h.objectives_array(current_obj,8);
                vissum = zeros(1,size(h.iz_data{iz_num,1}.interest1,2));
                for z_num = 1:size(h.f_array,1)
                    for f_num = 1:size(h.f_array,2)
                        if h.objectives_tzp1_array(z_num,f_num,current_obj) > 0
                            vissum = vissum + visresults{iz_num,1}.zone{z_num,1}.facility{f_num};
                        end
                    end
                end
                sharedvis = find(vissum == 0);
                sharedvis = size(sharedvis,2);
                division = size(h.iz_data{iz_num,1}.interest1,2)/100;
                
                Obj_matrix(obj_cnt,i) = sharedvis/division;
                obj_cnt = obj_cnt + 1;
                notdone = 0;
            end
            
            if h.objectives_array(current_obj,1) == 7
                iz_num = h.objectives_array(current_obj,8);
                vissum = zeros(1,size(h.iz_data{iz_num,1}.interest1,2));
                
                for z_num = 1:size(h.f_array,1)
                    for f_num = 1:size(h.f_array,2)
                        if h.objectives_tzp1_array(z_num,f_num,current_obj) > 0
                            vissum = vissum + visresults{iz_num,1}.zone{z_num,1}.facility{f_num};
                        end
                    end
                end
                
                sharedvis = find(vissum >=h.obj3_shared_nf);
                sharedvis = size(sharedvis,2);
                division = size(h.iz_data{iz_num,1}.interest1,2)/100;
                Obj_matrix(obj_cnt,i) = sharedvis/division;
                obj_cnt = obj_cnt + 1;
                notdone = 0;
            end
            
            if notdone
                
                for z_num = 1:size(h.f_array,1)
                    obj_sites{z_num} = [];
                    for f_num = 1:size(h.f_array,2)
                        if h.objectives_tzp1_array(z_num,f_num,current_obj) == 1
                            obj_sites{z_num} =  cat(2,obj_sites{z_num},localzonepoints{z_num,f_num});
                        end
                    end
                end
                
                if h.objectives_array(current_obj,1) == 3 || h.objectives_array(current_obj,1) == 4
                    obj_sites1 = [];
                    for z_num = 1:size(h.f_array,1)
                        for f_num = 1:size(h.f_array,2)
                            if h.objectives_tzp1_array(z_num,f_num,current_obj) == 1
                                obj_sites1 =  cat(2,obj_sites1,refgrid1points{z_num,f_num});
                            end
                        end
                    end
                    
                    obj_sites2 = [];
                    for z_num = 1:size(h.f_array,1)
                        for f_num = 1:size(h.f_array,2)
                            if h.objectives_tzp2_array(z_num,f_num,current_obj) == 1
                                obj_sites2 =  cat(2,obj_sites2,refgrid1points{z_num,f_num});
                            end
                        end
                    end
                end
                
                
                if h.objectives_array(current_obj,1) == 1
                    crit_values = [];
                    for z_num = 1:size(h.f_array,1)
                        if ~isempty(obj_sites{z_num})
                            crit_values = cat(2,crit_values,h.zone_data{z_num,1}.criteria{h.objectives_array(current_obj,17)}(obj_sites{z_num}));
                        end
                    end
                    Obj_matrix(obj_cnt,i) = min(crit_values);
                    obj_cnt = obj_cnt + 1;
                end
                
                if h.objectives_array(current_obj,1) == 2
                    crit_values = [];
                    for z_num = 1:size(h.f_array,1)
                        if ~isempty(obj_sites{z_num})
                            crit_values = cat(2,crit_values,h.zone_data{z_num,1}.criteria{h.objectives_array(current_obj,17)}(obj_sites{z_num}));
                        end
                    end
                    crit_values = 1./crit_values;
                    Obj_matrix(obj_cnt,i) = min(crit_values);
                    obj_cnt = obj_cnt + 1;
                end
                
                if h.objectives_array(current_obj,1) == 3
                    [min_prox,~] = calc_dist(obj_sites1,obj_sites2,...
                        h.latdist,h.londist,...
                        h.sizeTerrain1,1);
                    Obj_matrix(obj_cnt,i) = min_prox;
                    obj_cnt = obj_cnt + 1;
                end
                
                if h.objectives_array(current_obj,1) == 4
                    
                    [~,max_prox] = calc_dist(obj_sites1,obj_sites2,...
                        h.latdist,h.londist,...
                        h.sizeTerrain1,2);
                    Obj_matrix(obj_cnt,i) = 1/max_prox;
                    obj_cnt = obj_cnt + 1;
                end
                
            end
            
        end
        
    end
    
end
%
%     plot(Obj_matrix(1,:),Obj_matrix(2,:),'*');
%     pause(0.2)

end
