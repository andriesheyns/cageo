function [Q] = generate_children...
    (P,zone_n_locs,pointdata,...
    prank,cd,tour_size,...
    pool_size,population_size,...
    crossover_p,mutation_p,latdist,londist,...
    num_c_points,h,current_res)

totalnum_allf_allSZ = sum(sum(h.f_array));

Q_population_size = population_size;
if mod(population_size,2) ~= 0
    Q_population_size = population_size - 1;
end

Q=zeros(totalnum_allf_allSZ,Q_population_size);

pool = selection(prank,cd,tour_size,pool_size,population_size);

for i=1:(Q_population_size/2)
    
    if crossover_p > rand()
        crossoverdone = 0;
        while ~crossoverdone
            p1 = 0;
            p2 = 0;
            while p1 == p2
                p1=pool(floor(rand*pool_size) +1);
                p2=pool(floor(rand*pool_size) +1);
            end
            
            if num_c_points == 1
                [Q(:,i*2-1:i*2), crossoverpossible] = crossover_single_point...
                    (P(:,p1),P(:,p2),...
                    zone_n_locs,pointdata,...
                    latdist,londist,h);
                if crossoverpossible
                    crossoverdone = 1;
                end
            elseif num_c_points == 2
                [Q(:,i*2-1:i*2), crossoverpossible] = crossover_multi_point...
                    (P(:,p1),P(:,p2),...
                    zone_n_locs,pointdata,...
                    latdist,londist,h);
                if crossoverpossible
                    crossoverdone = 1;
                end
            elseif num_c_points == 3
                [Q(:,i*2-1:i*2), crossoverpossible] = crossover_three_point...
                    (P(:,p1),P(:,p2),...
                    zone_n_locs,pointdata,...
                    latdist,londist,h);
                if crossoverpossible
                    crossoverdone = 1;
                end
            elseif num_c_points == 0
                [Q(:,i*2-1:i*2), crossoverpossible] = crossover_three_point_diff_only...
                    (P(:,p1),P(:,p2),...
                    zone_n_locs,pointdata,...
                    latdist,londist,h);
                if crossoverpossible
                    crossoverdone = 1;
                end
            end
        end
    else
        p1 = 0;
        p2 = 0;
        while p1 == p2
            p1=pool(floor(rand*pool_size) +1);
            p2=pool(floor(rand*pool_size) +1);
        end
        Q(:,i*2-1) = P(:,p1);
        Q(:,i*2) = P(:,p2);
    end
    
end

for i=1:(Q_population_size)
    
    if (mutation_p>rand())
%         if get(h.local_mutation_select,'Value') == 0
            
            [Q(:,i)]=mutation...
                (Q(:,i),...
                zone_n_locs,pointdata,...
                latdist,londist,...
                h);
%         elseif get(h.local_mutation_select,'Value') == 1
%             [Q(:,i)]=mutation_local_v2...
%                 (Q(:,i),...
%                 zone_n_locs,pointdata,...
%                 latdist,londist,...
%                 h,current_res);
            
        %end
        
    end
    
    before = 0;
    for z_num = 1:size(h.f_array,1)
        for f_num = 1:size(h.f_array,2)
            if h.f_array(z_num,f_num) ~= 0 && h.f_array(z_num,f_num) >= 2
                Q(before+1:before+h.f_array(z_num,f_num),:) = sort(Q(before+1:before+h.f_array(z_num,f_num),:));
                before = before + h.f_array(z_num,f_num);
            end
        end
    end
    
end