function [ resultP, resultObj, resultprank ] = filter_front_prank( P,Obj, prank,f_array)

before = 0;
for z_num = 1:size(f_array,1)
    for f_num = 1:size(f_array,2)
        if f_array(z_num,f_num) >= 2
            P(before+1:before+f_array(z_num,f_num),:) = sort(P(before+1:before+f_array(z_num,f_num),:));
            before = before + f_array(z_num,f_num);
        end
    end
end

resultP = unique(P','rows')';

resultObj = zeros(size(Obj,1),size(resultP,2));
resultprank = zeros(1,size(resultP,2));

for solution = 1:size(resultP,2)
    found = 0;
    compare = 1;
    while ~found
        if resultP(:,solution) == P(:,compare)
            resultObj(:,solution) = Obj(:,compare);
            resultprank(1,solution) = prank(1,compare);
            found = 1;
        end
        compare = compare + 1;
    end
    if any(0 == resultP(:,solution))
        remove = cat(2,remove,solution);
    end
end

end

