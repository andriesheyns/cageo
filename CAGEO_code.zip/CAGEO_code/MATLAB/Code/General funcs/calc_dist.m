function [min_prox,max_prox] = ...
    calc_dist(P_res1_group1,...
    P_res1_group2,latdist,londist,...
    max_matrix_size,...
    testmaxminorminmaxprox)

% P_res1_group1
% P_res1_group2

n_f_tocheck1 = size(P_res1_group1,2);
n_f_tocheck2 = size(P_res1_group2,2);

if isempty(P_res1_group1) || isempty(P_res1_group2)
    
    max_prox = 99999999;
    min_prox = 99999999;
    
else
    
    if n_f_tocheck1 == 1 && n_f_tocheck2== 1 && P_res1_group1 == P_res1_group2
        max_prox = 99999999;
        min_prox = 99999999;
    else
        
        [candidaterows,candidatecols] = ind2sub(max_matrix_size,P_res1_group1);
        [candidaterows2,candidatecols2] = ind2sub(max_matrix_size,P_res1_group2);
        
        distmatrix = zeros(n_f_tocheck1,n_f_tocheck2);
        
        min_prox = 0;
        max_prox = 0;
        
        for f1 = 1:n_f_tocheck1
            for f2 = 1:n_f_tocheck2
                
                if P_res1_group1(f1) ~= P_res1_group2(f2)
                    latdiff = candidaterows(f1) - candidaterows2(f2);
                    londiff = candidatecols(f1) - candidatecols2(f2);
                    dist = sqrt((latdist*latdiff)^2 + (londist*londiff)^2);
                    
                    distmatrix(f1,f2) = dist;
                else
                    if testmaxminorminmaxprox == 1
                        distmatrix(f1,f2) = 99999999;
                    end
                end
            end
        end
        
        if testmaxminorminmaxprox == 1
            min_prox = min(min(distmatrix));
        end
        if testmaxminorminmaxprox == 2
            max_prox = max(max(distmatrix));
        end
        
    end
    
end


% distmatrix
%  min_prox
%  max_prox
%  pause

end

