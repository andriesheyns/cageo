function [F, front_size, prank, front] = partition_n_obj(obj_P,n_obj)

    n_P = size(obj_P,2);
    
    Sp = zeros(n_P,n_P);
    dp = zeros(1,n_P);
    
    prank = zeros(1,n_P);
    F = zeros(1,n_P);
    addrow = zeros(1,n_P);
    front_size = zeros(1,n_P);
    
    for i=1:n_P
        for j=1:n_P
            
            okay = 1;
            obj_num = 1;
            g_cnt = 0;
            while okay && obj_num <= n_obj
                okay = obj_P(obj_num,i)>=obj_P(obj_num,j);
                g_cnt = g_cnt + (obj_P(obj_num,i)>obj_P(obj_num,j));
                obj_num = obj_num+1;
            end
            if okay && g_cnt > 0
                Sp(i,j)=1;
            end
            
            okay = 1;
            obj_num = 1;
            g_cnt = 0;
            while okay && obj_num <= n_obj
                okay = obj_P(obj_num,i)<=obj_P(obj_num,j);
                g_cnt = g_cnt + (obj_P(obj_num,i)<obj_P(obj_num,j));
                obj_num = obj_num+1;
            end
            if okay && g_cnt > 0
                dp(i)=dp(i)+1;
            end
            
        end
        if (dp(i)==0)
            prank(i)=1;
            front_size(1)=front_size(1)+1;
            F(1,front_size(1))=i;
        end
    end
    
    front=1;
    F = cat(1,F,addrow);
    
    sol_count=front_size(1);
       
    while (sol_count<n_P)
        for i=1:front_size(front)
            sol1=F(front,i);
            for sol2=1:n_P
                if (Sp(sol1,sol2)==1)
                    dp(sol2)=dp(sol2)-1;
                    if (dp(sol2)==0)
                        prank(sol2)=front+1;
                        front_size(front+1)=front_size(front+1)+1;
                        F(front+1,front_size(front+1))=sol2;
                    end
                end
            end        
        end
        sol_count=sol_count+front_size(front+1);
        front=front+1;
        F = cat(1,F,addrow);
    end   

end