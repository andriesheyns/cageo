function [visresults, lostime]...
    ...
    = read_f_array(viewsheds,n_obj,...
    refgrid1points,h)

lostime = [0 0];

do_vis_array = zeros(size(h.f_array,1),size(h.f_array,2),size(h.iz_data,1));

for current_obj_num = 1:n_obj
    if h.objectives_array(current_obj_num,8) ~= 0
        do_vis_array(:,:,h.objectives_array(current_obj_num,8)) = ...
            do_vis_array(:,:,h.objectives_array(current_obj_num,8)) + h.objectives_tzp1_array(:,:,current_obj_num);
    end
end

for do_iz = 1:size(h.iz_data,1)
    if sum(sum(do_vis_array(:,:,do_iz))) > 0
        screen_m = h.iz_data{do_iz,1}.screen_m;
        for z_num = 1:size(h.f_array,1)
            for f_num = 1:size(h.f_array,2)
                
                blankmatrix = h.BlankTerrain;
                
                if do_vis_array(z_num,f_num,do_iz) > 0
                    for f_count = 1:h.f_array(z_num,f_num)
  
                        
                        site_num = refgrid1points{z_num,f_num}(f_count);
                        
                            [Visarray,extent,extralostime] = read_visarray_screen_from_bin(h.binsdir,...
                                site_num,h.LOSterrain,f_num,screen_m);
                            lostime = lostime + extralostime;
                        
                        rowmin = extent(1);
                        rowdiff = extent(2);
                        colmin = extent(3);
                        coldiff = extent(4);
                        rownum = 1;
                        for row = rowmin:rowmin+rowdiff
                            blankmatrix(row,colmin:colmin+coldiff) = blankmatrix(row,colmin:colmin+coldiff) + Visarray(1,(rownum-1)*(coldiff+1)+1:(rownum)*(coldiff+1));
                            rownum = rownum + 1;
                        end

                    end
                end
                
                visresults{do_iz,1}.zone{z_num,1}.facility{f_num} = blankmatrix(h.iz_data{do_iz,1}.interest1);
                
            end
        end
    end
end

